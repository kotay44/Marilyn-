package nl.marilyn.origineel;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Saves ONLY the user's personal gateway access token, never an OpenAI API key. */
final class SecureToken {
    private static final String ALIAS = "marilyn_worker_access_v6";
    private static SecretKey key() throws Exception {
        KeyStore store=KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        SecretKey key=(SecretKey)store.getKey(ALIAS,null);
        if(key!=null) return key;
        KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).build());
        return generator.generateKey();
    }
    static void save(Context ctx, String token) throws Exception {
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE,key());
        byte[] cipherText=cipher.doFinal(token.getBytes(StandardCharsets.UTF_8));
        ctx.getSharedPreferences("marilyn_ai",Context.MODE_PRIVATE).edit()
            .putString("token_ct",Base64.encodeToString(cipherText,Base64.NO_WRAP))
            .putString("token_iv",Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP)).apply();
    }
    static String load(Context ctx) {
        try {
            android.content.SharedPreferences p=ctx.getSharedPreferences("marilyn_ai",Context.MODE_PRIVATE);
            String iv=p.getString("token_iv","");String encrypted=p.getString("token_ct","");
            if(iv.isEmpty()||encrypted.isEmpty())return "";
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)));
            return new String(c.doFinal(Base64.decode(encrypted,Base64.NO_WRAP)),StandardCharsets.UTF_8);
        }catch(Exception e){return "";}
    }
    static void clear(Context ctx){ctx.getSharedPreferences("marilyn_ai",Context.MODE_PRIVATE).edit()
        .remove("token_ct").remove("token_iv").apply();}
    private SecureToken(){}
}
