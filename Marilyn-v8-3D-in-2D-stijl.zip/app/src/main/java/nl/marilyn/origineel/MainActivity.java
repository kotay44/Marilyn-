package nl.marilyn.origineel;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_SPEECH = 20;
    private static final int REQUEST_NOTIFICATION = 21;
    private static final int INK = Color.rgb(106, 52, 82);
    private static final int PINK = Color.rgb(255, 237, 248);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private ImageView figure;
    private Marilyn3DView preview;
    private boolean threeD;
    private Button modeButton, filmButton, greetButton;
    private TextView poseLabel, sizeLabel, overlayStatus;
    private Button overlayButton, autoButton, languageButton, voiceButton, tapButton, recognitionButton;
    private TextView voiceLabel, pitchLabel, rateLabel;
    private SeekBar sizeSeek;
    private volatile boolean voiceReady=false;
    private TextToSpeech tts;
    private int pose, size;
    private boolean automatic;
    private final Runnable autoStep = new Runnable() {
        @Override public void run() {
            if (!automatic) return;
            setPose((pose + 1) % MarilynData.IMAGES.length);
            handler.postDelayed(this, 3400);
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pose = MarilynData.validPose(getSharedPreferences("marilyn_options", MODE_PRIVATE).getInt("pose", 6));
        size = MarilynData.validSize(getSharedPreferences("marilyn_options", MODE_PRIVATE).getInt("size", 100));
        automatic = getSharedPreferences("marilyn_options", MODE_PRIVATE).getBoolean("auto", false);
        threeD = getSharedPreferences("marilyn_options", MODE_PRIVATE).getBoolean("three_d", true);
        tts = new TextToSpeech(this, result -> {
            voiceReady = (result == TextToSpeech.SUCCESS);
            if (voiceReady && tts != null) {
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { runOnUiThread(() -> showTalking(true)); }
                    @Override public void onDone(String id) { runOnUiThread(() -> showTalking(false)); }
                    @Override public void onError(String id) { runOnUiThread(() -> showTalking(false)); }
                });
                runOnUiThread(() -> updateVoiceSettings());
            }
        });
        makeScreen();
        if (automatic) handler.postDelayed(autoStep, 3400);
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private TextView text(String t, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(INK);
        v.setGravity(Gravity.CENTER);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }
    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTextColor(INK);
        b.setBackground(bg(Color.rgb(255, 210, 229), 12));
        return b;
    }
    private void makeScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(PINK);
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(dp(14), dp(18), dp(14), dp(24));
        scroll.addView(column);
        setContentView(scroll);

        TextView title = text("💕 Marilyn Assistant", 26, true);
        column.addView(title, new LinearLayout.LayoutParams(-1, dp(58)));
        TextView subtitle = text("3D-Marilyn in de stijl van jouw favoriete 2D-figuurtje • draai- en versleepbaar", 14, false);
        column.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(50)));

        modeButton = button("");
        addWide(column, modeButton);
        modeButton.setOnClickListener(v -> {
            threeD = !threeD;
            getSharedPreferences("marilyn_options", MODE_PRIVATE).edit().putBoolean("three_d", threeD).apply();
            update3DMode();
            serviceCommand(OverlayService.ACTION_REFRESH);
        });
        filmButton = button("");
        addWide(column,filmButton);
        filmButton.setOnClickListener(v -> {
            int next=(getSharedPreferences("marilyn_options",MODE_PRIVATE).getInt("face_mode",0)+1)%3;
            getSharedPreferences("marilyn_options",MODE_PRIVATE).edit().putInt("face_mode",next).apply();
            if(preview!=null)preview.setFaceMode(next);
            updateFilmButton();
            serviceCommand(OverlayService.ACTION_REFRESH);
        });
        updateFilmButton();

        LinearLayout stage = new LinearLayout(this);
        stage.setGravity(Gravity.CENTER);
        stage.setBackground(bg(Color.rgb(255, 246, 250), 28));
        figure = new ImageView(this);
        figure.setScaleType(ImageView.ScaleType.FIT_CENTER);
        figure.setImageResource(MarilynData.IMAGES[pose]);
        FrameLayout layered = new FrameLayout(this);
        layered.addView(figure, new FrameLayout.LayoutParams(-1, -1));
        preview = new Marilyn3DView(this);
        preview.setPose(pose);
        preview.setFaceMode(getSharedPreferences("marilyn_options",MODE_PRIVATE).getInt("face_mode",0));
        preview.setAngle(getSharedPreferences("marilyn_options", MODE_PRIVATE).getFloat("yaw", 0f));
        layered.addView(preview, new FrameLayout.LayoutParams(-1, -1));
        stage.addView(layered, new LinearLayout.LayoutParams(dp(190), dp(365)));
        update3DMode();
        LinearLayout.LayoutParams stageLp = new LinearLayout.LayoutParams(-1, dp(382));
        stageLp.setMargins(0, dp(8), 0, dp(8));
        column.addView(stage, stageLp);
        poseLabel = text("Marilyn: " + MarilynData.NAMES[pose], 19, false);
        column.addView(poseLabel, new LinearLayout.LayoutParams(-1, dp(52)));

        TextView spinLabel = text("🌐 Draai het 3D-model ook van opzij en van achteren", 14, false);
        column.addView(spinLabel, new LinearLayout.LayoutParams(-1, dp(47)));
        LinearLayout spinning = new LinearLayout(this);
        spinning.setOrientation(LinearLayout.HORIZONTAL);
        for (String label : new String[]{"↶ Links", "● Voorkant", "Rechts ↷"}) {
            Button spin = button(label);
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, dp(55), 1f);
            sp.setMargins(dp(3),0,dp(3),0);
            spinning.addView(spin, sp);
            spin.setOnClickListener(v -> {
                float old = getSharedPreferences("marilyn_options", MODE_PRIVATE).getFloat("yaw", 0f);
                float value = label.startsWith("↶") ? old - 30f : (label.startsWith("Rechts") ? old + 30f : 0f);
                getSharedPreferences("marilyn_options", MODE_PRIVATE).edit().putFloat("yaw", value).apply();
                if (preview != null) preview.setAngle(value);
                serviceCommand(OverlayService.ACTION_REFRESH);
            });
        }
        column.addView(spinning);
                String[] symbol = {"🌸 ", "➡️ ", "⬅️ ", "👋 ", "✨ ", "🥺 ", "☁️ ", "🤔 ", "💕 "};
        for (int row = 0; row < 3; row++) {
            LinearLayout group = new LinearLayout(this);
            group.setOrientation(LinearLayout.HORIZONTAL);
            for (int col = 0; col < 3; col++) {
                int index = row * 3 + col;
                Button action = button(symbol[index] + MarilynData.NAMES[index]);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(67), 1f);
                lp.setMargins(dp(3), dp(3), dp(3), dp(3));
                group.addView(action, lp);
                action.setOnClickListener(v -> setPose(index));
            }
            column.addView(group);
        }
        sizeLabel = text("Grootte Marilyn: " + size + "% (75–200%)", 17, true);
        sizeLabel.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(-1, dp(56));
        labelLp.setMargins(dp(6), dp(6), 0, 0);
        column.addView(sizeLabel, labelLp);
        SeekBar seek = new SeekBar(this);
        sizeSeek=seek;
        seek.setMax(125);
        seek.setProgress(size - 75);
        column.addView(seek);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                size = MarilynData.validSize(progress + 75);
                sizeLabel.setText("Grootte Marilyn: " + size + "% (75–200%)");
                getSharedPreferences("marilyn_options", MODE_PRIVATE).edit().putInt("size", size).apply();
                serviceCommand(OverlayService.ACTION_REFRESH);
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });

        autoButton = button(automatic ? "⏸ Automatische beweging stoppen" : "▶ Automatisch bewegen");
        addWide(column, autoButton);
        autoButton.setOnClickListener(v -> {
            automatic = !automatic;
            getSharedPreferences("marilyn_options", MODE_PRIVATE).edit().putBoolean("auto", automatic).apply();
            handler.removeCallbacks(autoStep);
            if (automatic) handler.postDelayed(autoStep, 3400);
            autoButton.setText(automatic ? "⏸ Automatische beweging stoppen" : "▶ Automatisch bewegen");
            serviceCommand(OverlayService.ACTION_REFRESH);
        });
        greetButton = button("");
        addWide(column,greetButton);
        updateGreetingLabel();
        greetButton.setOnClickListener(v -> {
            boolean enabled=!getSharedPreferences("marilyn_options",MODE_PRIVATE).getBoolean("greet_unlock",false);
            getSharedPreferences("marilyn_options",MODE_PRIVATE).edit().putBoolean("greet_unlock",enabled).apply();
            updateGreetingLabel();
            Toast.makeText(this,enabled ? "Marilyn kan je nu af en toe spontaan begroeten" : "Spontane begroetingen uit",Toast.LENGTH_SHORT).show();
        });
        addWideLabel(column,text("Spontane begroetingen zijn standaard UIT. Als je ze aanzet, spreekt ze maximaal eens per 3 uur na ontgrendelen, alleen tussen 09:00 en 22:00, zolang Marilyn actief is.",13,false));
        TextView aiTitle=text("💬 Marilyn 7.0 – Vrije AI-gesprekken",21,true);
        addWideLabel(column,aiTitle);
        TextView aiInfo=text("Praat onbeperkt over onderwerpen naar keuze (afhankelijk van API-gebruik), stel vragen en krijg adviezen. Marilyn vraagt ook zelf door. Voor deze functie is een privé AI-verbinding nodig.",14,false);
        addWideLabel(column,aiInfo);
        Button aiButton=button("❤️ Open echt gesprek met Marilyn");
        addWide(column,aiButton);
        aiButton.setOnClickListener(v->startActivity(new Intent(this,ConversationActivity.class)));
        // Voice settings work with the voices actually installed on this Samsung.
        TextView voiceTitle=text("🎙 Stemstudio – klassiek filmgeluid (benadering)",17,true);
        addWideLabel(column,voiceTitle);
        TextView caveat=text("Originele Marilyn Monroe-stem is NIET ingebouwd. De beschikbare Android-stemmen bepalen de klank.",13,false);
        addWideLabel(column,caveat);
        languageButton=button("");
        addWide(column,languageButton);
        languageButton.setOnClickListener(v->{
            boolean en=!VoiceStyle.english(this);
            VoiceStyle.prefs(this).edit().putBoolean("voice_en",en).putInt("voice_index",0).apply();
            updateVoiceSettings();
            serviceCommand(OverlayService.ACTION_REFRESH);
            say(en ? "Of course, darling! I'll speak English from now on."
                   : "Natuurlijk! Vanaf nu spreek ik Nederlands.");
        });
        voiceButton=button("🔄 Andere stem proberen");
        addWide(column,voiceButton);
        voiceButton.setOnClickListener(v->{
            if(!voiceReady || tts==null) { Toast.makeText(this,"Spraakmodule nog niet beschikbaar",Toast.LENGTH_SHORT).show();return; }
            int count=VoiceStyle.candidates(this,tts).size();
            if(count<2){Toast.makeText(this,"Er is geen tweede geïnstalleerde stem beschikbaar.",Toast.LENGTH_LONG).show();return;}
            int index=VoiceStyle.prefs(this).getInt("voice_index",0);
            VoiceStyle.prefs(this).edit().putInt("voice_index",(index+1)%count).apply();
            updateVoiceSettings();
            say(VoiceStyle.english(this)?"Hello there, darling!":"Hallo, wat fijn dat je er bent!");
        });
        voiceLabel=text("Stem wordt geladen...",13,false);
        addWideLabel(column,voiceLabel);
        pitchLabel=text("Toonhoogte: "+VoiceStyle.pitchPercent(this)+"%",14,false);
        addWideLabel(column,pitchLabel);
        SeekBar pitchSlider=new SeekBar(this);
        pitchSlider.setMax(65);pitchSlider.setProgress(VoiceStyle.pitchPercent(this)-75);
        column.addView(pitchSlider);
        pitchSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar b,int p,boolean user){
                if(!user)return;
                VoiceStyle.prefs(MainActivity.this).edit().putInt("voice_pitch",75+p).apply();
                updateVoiceSettings();
            }
            @Override public void onStartTrackingTouch(SeekBar b){}
            @Override public void onStopTrackingTouch(SeekBar b){}
        });
        rateLabel=text("Spreeksnelheid: "+VoiceStyle.ratePercent(this)+"%",14,false);
        addWideLabel(column,rateLabel);
        SeekBar rateSlider=new SeekBar(this);
        rateSlider.setMax(50);rateSlider.setProgress(VoiceStyle.ratePercent(this)-65);
        column.addView(rateSlider);
        rateSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar b,int p,boolean user){
                if(!user)return;
                VoiceStyle.prefs(MainActivity.this).edit().putInt("voice_rate",65+p).apply();
                updateVoiceSettings();
            }
            @Override public void onStartTrackingTouch(SeekBar b){}
            @Override public void onStopTrackingTouch(SeekBar b){}
        });
        tapButton=button("");
        addWide(column,tapButton);
        tapButton.setOnClickListener(v->{
            boolean active=!VoiceStyle.speakOnTap(this);
            VoiceStyle.prefs(this).edit().putBoolean("speak_on_tap",active).apply();
            updateVoiceSettings();
        });
        updateVoiceSettings();
        Button talk = button("🔊 Marilyn laten praten / stem testen");
        addWide(column, talk);
        talk.setOnClickListener(v -> sayPose(pose));
        TextView hint=text("Zeg bijvoorbeeld: ‘Marilyn, spreek Nederlands’, ‘Marilyn, spreek Engels’, "
                + "‘Wat zei je?’ of ‘Marilyn, speak Dutch’. Marilyn onthoudt de gekozen spreektaal.",14,false);
        addWideLabel(column,hint);
        Button listen = button("🎙 Oudere vaste commando’s – Nederlands");
        addWide(column, listen);
        listen.setOnClickListener(v -> listen(false));
        Button listenEn = button("🎙 Old preset commands – English");
        addWide(column, listenEn);
        listenEn.setOnClickListener(v -> listen(true));
        recognitionButton=button("");
        addWide(column,recognitionButton);
        recognitionButton.setOnClickListener(v -> {
            boolean en=!VoiceStyle.prefs(this).getBoolean("recognize_en",false);
            VoiceStyle.prefs(this).edit().putBoolean("recognize_en",en).apply();
            updateVoiceSettings();
        });
        overlayButton = button("");
        addWide(column, overlayButton);
        overlayButton.setOnClickListener(v -> toggleOverlay());
        overlayStatus = text("", 14, false);
        column.addView(overlayStatus);
        TextView help = text("3D is een voorlopige interpretatie; de originele beelden blijven in 2D beschikbaar. "
                + "Op je startscherm: sleep met één vinger, draai in 3D met twee vingers. "
                + "HOUD MARILYN 1 SECONDE VAST om een echt gesprek te openen. "
                + "Dat opent de Android-spraakherkenning (niet continu meeluisteren). "
                + "De taal voor het herkennen van jouw stem kies je hierboven. "
                + "Marilyn spreekt terug in de door jou gekozen taal. "
                + "Ze kan de vaste app-zinnen herhalen in de andere taal, maar is nog geen algemene vertaal- of chatassistent. "
                + "Stoppen kan via de app of de melding.", 14, false);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(-1, -2);
        hlp.setMargins(dp(8), dp(16), dp(8), dp(8));
        column.addView(help, hlp);
        updateOverlayLabel();
    }
    private void updateFilmButton() {
        if(filmButton==null)return;
        int mode=getSharedPreferences("marilyn_options",MODE_PRIVATE).getInt("face_mode",0);
        filmButton.setText(mode==0
            ? "💕 3D met jouw 2D-gezicht AAN – tik voor filmgezicht"
            : mode==1
                ? "🎬 Filmgezicht AAN – tik voor getekend 3D-gezicht"
                : "🎨 Getekend 3D-gezicht AAN – tik voor jouw 2D-gezicht");
    }
    private void updateGreetingLabel() {
        if(greetButton!=null)greetButton.setText(getSharedPreferences("marilyn_options",MODE_PRIVATE).getBoolean("greet_unlock",false)
            ? "💕 Spontaan begroeten: AAN (tik om uit te zetten)"
            : "🔕 Spontaan begroeten: UIT (tik om aan te zetten)");
    }
    private void update3DMode() {
        if (modeButton != null) modeButton.setText(threeD
                ? "🌐 ECHT 3D AAN — tik voor originele 2D"
                : "🖼 Originele 2D AAN — tik voor echt 3D");
        if (figure != null) figure.setVisibility(threeD ? View.GONE : View.VISIBLE);
        if (preview != null) preview.setVisibility(threeD ? View.VISIBLE : View.GONE);
    }
    private void addWideLabel(LinearLayout parent,TextView v) {
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(dp(6),dp(7),dp(6),dp(7));
        parent.addView(v,lp);
    }
    private void updateVoiceSettings() {
        if(recognitionButton!=null) recognitionButton.setText(
                VoiceStyle.prefs(this).getBoolean("recognize_en",false)
                ? "🎤 Op startscherm luisteren naar: ENGELS (tik voor Nederlands)"
                : "🎤 Op startscherm luisteren naar: NEDERLANDS (tik voor Engels)");
        if(languageButton!=null)languageButton.setText(VoiceStyle.english(this)
                ?"🌎 Marilyn spreekt Engels (VS) – tik voor Nederlands"
                :"🇳🇱 Marilyn spreekt Nederlands – tik voor Engels");
        if(tapButton!=null)tapButton.setText(VoiceStyle.speakOnTap(this)
                ?"🔊 Marilyn praat bij aanraken: AAN":"🔇 Marilyn praat bij aanraken: UIT");
        if(pitchLabel!=null)pitchLabel.setText("Toonhoogte: "+VoiceStyle.pitchPercent(this)+"%");
        if(rateLabel!=null)rateLabel.setText("Spreeksnelheid: "+VoiceStyle.ratePercent(this)+"%");
        if(voiceReady && tts!=null) {
            String label=VoiceStyle.apply(this,tts);
            if(voiceLabel!=null)voiceLabel.setText("Geselecteerde stem: "+label);
        }
    }
    private void showTalking(boolean talking) {
        if(preview!=null)preview.setSpeaking(talking);
        if(OverlayService.active) {
            Intent intent=new Intent(this,OverlayService.class);
            intent.setAction(OverlayService.ACTION_SPEECH);
            intent.putExtra("is_speaking",talking);
            startForegroundService(intent);
        }
    }
    private void addWide(LinearLayout parent, Button b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(55));
        lp.setMargins(dp(3), dp(6), dp(3), dp(5));
        parent.addView(b, lp);
    }
    private void setPose(int next) {
        pose = MarilynData.validPose(next);
        getSharedPreferences("marilyn_options", MODE_PRIVATE).edit().putInt("pose", pose).apply();
        figure.setImageResource(MarilynData.IMAGES[pose]);
        if (preview != null) preview.setPose(pose);
        poseLabel.setText("Marilyn: " + MarilynData.NAMES[pose]);
        figure.animate().cancel();
        if (pose == 4) {
            figure.animate().translationY(-dp(23)).setDuration(230).withEndAction(
                () -> figure.animate().translationY(0).setDuration(350).start()).start();
        } else if (pose == 3) {
            figure.animate().rotation(6).setDuration(170).withEndAction(
                () -> figure.animate().rotation(-6).setDuration(170).withEndAction(
                    () -> figure.animate().rotation(0).setDuration(170).start()).start()).start();
        }
        serviceCommand(OverlayService.ACTION_REFRESH);
    }
    private void serviceCommand(String action) {
        if (!OverlayService.active) return;
        Intent i = new Intent(this, OverlayService.class);
        i.setAction(action);
        startForegroundService(i);
    }
    private void updateOverlayLabel() {
        if (overlayButton == null) return;
        overlayButton.setText(OverlayService.active ? "✖ Zwevende Marilyn stoppen" : "💕 Marilyn LOS op startscherm tonen");
        overlayStatus.setText(OverlayService.active
            ? "Marilyn zweeft los op je scherm. Sleep haar aan haar lichaam."
            : "Transparante overlay: geen venster en geen bediening boven Marilyn.");
    }
    private void toggleOverlay() {
        if (OverlayService.active) {
            stopService(new Intent(this, OverlayService.class));
            handler.postDelayed(this::updateOverlayLabel, 220);
            return;
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Sta 'Bovenop weergeven' toe en tik daarna nogmaals op de knop.", Toast.LENGTH_LONG).show();
            Intent manage = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(manage);
            return;
        }
        Intent i = new Intent(this, OverlayService.class);
        i.setAction(OverlayService.ACTION_START);
        startForegroundService(i);
        handler.postDelayed(this::updateOverlayLabel, 400);
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATION);
        }
    }
    @Override protected void onResume() {
        super.onResume();
        if (preview != null) preview.onResume();
        int savedPose=MarilynData.validPose(VoiceStyle.prefs(this).getInt("pose",pose));
        if(savedPose!=pose && figure!=null) setPose(savedPose);
        int savedSize=MarilynData.validSize(VoiceStyle.prefs(this).getInt("size",size));
        if(savedSize!=size){
            size=savedSize;
            if(sizeSeek!=null)sizeSeek.setProgress(size-75);
            if(sizeLabel!=null)sizeLabel.setText("Grootte Marilyn: "+size+"% (75–200%)");
        }
        updateVoiceSettings();
        handler.postDelayed(this::updateOverlayLabel, 180);
    }
    private void say(String phrase) {
        if (!voiceReady || tts==null) {
            Toast.makeText(this,"De tekst-naar-spraakstem wordt nog geladen.",Toast.LENGTH_SHORT).show();
            return;
        }
        VoiceStyle.apply(this,tts);
        tts.speak(phrase,TextToSpeech.QUEUE_FLUSH,null,"marilyn_main");
    }
    private void sayPose(int atPose) {
        SpokenCommand.rememberPhrase(this,atPose);
        say(VoiceStyle.line(this,atPose));
    }
    private void listen(boolean englishInput) {
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, englishInput ? "en-US" : "nl-NL");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, englishInput
                    ? "Try: Marilyn, speak Dutch or Marilyn, speak English"
                    : "Bijvoorbeeld: Marilyn, spreek Nederlands / spreek Engels");
            startActivityForResult(i, REQUEST_SPEECH);
        } catch (Exception e) {
            Toast.makeText(this, "Geen spraakherkenning beschikbaar op deze telefoon.", Toast.LENGTH_LONG).show();
        }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_SPEECH || resultCode != RESULT_OK || data == null) return;
        ArrayList<String> words = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if (words == null || words.isEmpty()) return;
        SpokenCommand.Outcome result = SpokenCommand.execute(this,words.get(0));
        if (result.newPose >= 0) setPose(result.newPose);
        if (result.sizeChanged) {
            size=MarilynData.validSize(VoiceStyle.prefs(this).getInt("size",100));
            if(sizeLabel!=null) sizeLabel.setText("Grootte Marilyn: " + size + "% (75–200%)");
        }
        if (result.languageChanged) updateVoiceSettings();
        if (result.sizeChanged || result.languageChanged) serviceCommand(OverlayService.ACTION_REFRESH);
        if (result.answer != null && !result.answer.isEmpty()) say(result.answer);
    }
    @Override protected void onPause() {
        if (preview != null) preview.onPause();
        super.onPause();
    }
    @Override protected void onDestroy() {
        handler.removeCallbacks(autoStep);
        showTalking(false);
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
