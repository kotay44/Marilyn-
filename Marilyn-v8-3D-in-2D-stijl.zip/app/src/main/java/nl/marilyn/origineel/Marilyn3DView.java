package nl.marilyn.origineel;

import android.content.Context;
import android.graphics.PixelFormat;
import android.opengl.GLSurfaceView;
import android.os.Handler;
import android.os.Looper;

/** A genuine offline OpenGL ES 2.0 mesh, not a flat photograph or sprite rotation. */
public class Marilyn3DView extends GLSurfaceView {
    private final Marilyn3DRenderer model;
    private final Handler ticker = new Handler(Looper.getMainLooper());
    private boolean attached;
    private final Runnable frame = new Runnable() {
        @Override public void run() {
            if (!attached) return;
            requestRender();
            ticker.postDelayed(this, 50); // 20 fps, reduced idle battery usage
        }
    };

    public Marilyn3DView(Context context) {
        super(context);
        setEGLContextClientVersion(2);
        setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        getHolder().setFormat(PixelFormat.TRANSLUCENT);
        setZOrderOnTop(true);
        model = new Marilyn3DRenderer(context);
        setRenderer(model);
        setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
        setPreserveEGLContextOnPause(true);
    }
    public void setFaceMode(int mode) { model.faceMode=Math.max(0,Math.min(2,mode)); requestRender(); }
    public void setPose(int pose) { model.pose = Math.max(0, Math.min(8, pose)); requestRender(); }
    public void setAngle(float angle) { model.yaw = angle; requestRender(); }
    public float getAngle() { return model.yaw; }
    public void setSpeaking(boolean yes) { model.speaking = yes; requestRender(); }
    public void wave() { model.waveUntil = android.os.SystemClock.uptimeMillis() + 1600L; requestRender(); }
    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        attached = true;
        ticker.removeCallbacks(frame);
        ticker.post(frame);
    }
    @Override protected void onDetachedFromWindow() {
        attached = false;
        ticker.removeCallbacks(frame);
        super.onDetachedFromWindow();
    }
}
