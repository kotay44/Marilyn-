package nl.marilyn.origineel;

final class MarilynData {
    static final int[] IMAGES = {
        R.drawable.marilyn_1, R.drawable.marilyn_2, R.drawable.marilyn_3,
        R.drawable.marilyn_4, R.drawable.marilyn_5, R.drawable.marilyn_6,
        R.drawable.marilyn_7, R.drawable.marilyn_8, R.drawable.marilyn_9
    };
    static final String[] NAMES = {
        "Rustig", "Naar rechts", "Naar links", "Zwaaien", "Springen",
        "Teleurgesteld", "Wachten", "Denken", "Beoordelen"
    };
    static final String[] SAY = {
        "Hallo! Wat leuk dat je er bent!", "Kijk, ik ga naar rechts.",
        "En nu ga ik naar links.", "Hallo daar!", "Jippie!",
        "Ach, dat is jammer.", "Ik wacht gezellig op je.",
        "Even nadenken hoor.", "Dat ziet er goed uit!"
    };
    static final String[] SAY_EN = {
        "Hello, darling! It's lovely to see you.",
        "Look, I'm stepping to the right.",
        "And now, a little step to the left.",
        "Oh, hello there, sweetheart!",
        "Isn't this wonderful!",
        "Oh dear... that's such a shame.",
        "I'll be right here when you need me.",
        "Hmm... let me think for a moment.",
        "Oh, I think that looks just lovely!"
    };
    static int validPose(int value) { return Math.max(0, Math.min(IMAGES.length - 1, value)); }
    static int validSize(int value) { return Math.max(75, Math.min(200, value)); }
    private MarilynData() {}
}
