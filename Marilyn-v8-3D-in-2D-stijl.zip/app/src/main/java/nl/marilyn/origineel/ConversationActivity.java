package nl.marilyn.origineel;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import android.os.Build;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** A real conversational UI. Android speech input & TTS + user-owned HTTPS AI gateway. */
public class ConversationActivity extends Activity {
    private static final int REQUEST_SPEECH=77;
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());
    private final JSONArray turns=new JSONArray();
    private LinearLayout conversation, root, settings;
    private ScrollView transcript;
    private TextView status, languageLabel;
    private EditText message, urlInput, tokenInput, memoryInput;
    private CheckBox speakToggle;
    private Button sendButton, microphoneButton, questionButton, languageButton;
    private TextToSpeech tts;
    private boolean ttsReady=false, pending=false, dead=false, settingsOpen=false;
    private String queuedSpeech=null;
    private SharedPreferences pref;

    private int dp(float d){return Math.round(getResources().getDisplayMetrics().density*d);}
    private int color(int r,int g,int b){return Color.rgb(r,g,b);}
    private GradientDrawable surface(int c){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(13));return d;}
    private TextView label(String value,int size){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color(88,47,74));t.setPadding(dp(8),dp(9),dp(8),dp(9));return t;}
    private Button button(String title){Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setTextSize(14);b.setTextColor(color(91,31,66));b.setBackground(surface(color(255,213,230)));return b;}
    private void add(LinearLayout to,View view){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(dp(5),dp(5),dp(5),dp(5));to.addView(view,lp);}
    private void horizontal(LinearLayout to,Button a,Button b){LinearLayout row=new LinearLayout(this);for(Button x:new Button[]{a,b}){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(54),1f);p.setMargins(dp(4),dp(4),dp(4),dp(4));row.addView(x,p);}to.addView(row);}

    @Override public void onCreate(Bundle saved){super.onCreate(saved);
        pref=getSharedPreferences("marilyn_ai",MODE_PRIVATE);
        restore();
        buildUI();
        tts=new TextToSpeech(this, code -> {
            ttsReady=code==TextToSpeech.SUCCESS;
            if(ttsReady && tts!=null){
                VoiceStyle.apply(this,tts);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
                    @Override public void onStart(String id){runOnUiThread(()->talking(true));}
                    @Override public void onDone(String id){runOnUiThread(()->talking(false));}
                    @Override public void onError(String id){runOnUiThread(()->talking(false));}
                });
                if(queuedSpeech!=null){String line=queuedSpeech;queuedSpeech=null;main.post(()->say(line));}
            }
        });
        if(getIntent()!=null && getIntent().getBooleanExtra("listen_now",false))main.postDelayed(this::listen,550);
    }
    private void buildUI(){
        ScrollView outer=new ScrollView(this); outer.setFillViewport(true);outer.setBackgroundColor(color(255,241,249));
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(10),dp(10),dp(10),dp(22));outer.addView(root);setContentView(outer);
        add(root,label("💕 Marilyn – vrije gesprekken",24));
        add(root,label("Ik ben een AI-personage geïnspireerd op de filmsfeer van Marilyn Monroe, niet Marilyn Monroe zelf.",12));
        languageButton=button(VoiceStyle.english(this)?"🌎 Antwoorden: Engels · wissel naar Nederlands":"🇳🇱 Antwoorden: Nederlands · wissel naar Engels");
        add(root,languageButton);languageButton.setOnClickListener(v->changeLanguage(!VoiceStyle.english(this)));
        transcript=new ScrollView(this);transcript.setFillViewport(false);transcript.setBackground(surface(Color.WHITE));
        conversation=new LinearLayout(this);conversation.setOrientation(LinearLayout.VERTICAL);conversation.setPadding(dp(5),dp(5),dp(5),dp(5));transcript.addView(conversation);
        LinearLayout.LayoutParams history=new LinearLayout.LayoutParams(-1,dp(310));history.setMargins(dp(5),dp(6),dp(5),dp(8));root.addView(transcript,history);
        render();
        status=label("",13);status.setGravity(Gravity.CENTER);add(root,status);
        message=new EditText(this);message.setHint("Zeg of typ iets voor Marilyn...");message.setTextSize(16);message.setMinLines(2);message.setMaxLines(5);message.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);message.setBackground(surface(Color.WHITE));message.setPadding(dp(12),dp(12),dp(12),dp(12));add(root,message);
        sendButton=button("💬 Verstuur");microphoneButton=button("🎤 Inspreken");horizontal(root,sendButton,microphoneButton);
        sendButton.setOnClickListener(v->submitInput());microphoneButton.setOnClickListener(v->listen());
        questionButton=button("💕 Marilyn, stel mij een interessante vraag");add(root,questionButton);questionButton.setOnClickListener(v->send("Stel mij één verrassende maar relevante vraag die aansluit bij onze eerdere gesprekken. Wees oprecht nieuwsgierig en wacht op mijn antwoord."));
        speakToggle=new CheckBox(this);speakToggle.setText("Antwoorden hardop uitspreken");speakToggle.setChecked(pref.getBoolean("speak",true));add(root,speakToggle);speakToggle.setOnCheckedChangeListener((b,on)->pref.edit().putBoolean("speak",on).apply());
        Button config=button("⚙ Privé-AI-verbinding instellen");add(root,config);
        settings=new LinearLayout(this);settings.setOrientation(LinearLayout.VERTICAL);settings.setVisibility(View.GONE);add(root,settings);
        config.setOnClickListener(v->{settingsOpen=!settingsOpen;settings.setVisibility(settingsOpen?View.VISIBLE:View.GONE);});
        add(settings,label("Een eigen beveiligde server koppelt deze app aan de AI. De OpenAI-API-sleutel hoort uitsluitend als Secret op je server, NOOIT in deze app.",13));
        add(settings,label("Wat mag Marilyn voor volgende gesprekken onthouden? (optioneel, deel geen gevoelige gegevens)",13));
        memoryInput=new EditText(this);memoryInput.setMinLines(2);memoryInput.setMaxLines(5);memoryInput.setTextSize(16);
        memoryInput.setHint("Bijvoorbeeld: Ik maak graag uitvindingen en hou van fitness...");
        memoryInput.setText(pref.getString("memory", ""));add(settings,memoryInput);
        urlInput=new EditText(this);urlInput.setSingleLine(true);urlInput.setTextSize(16);urlInput.setHint("https://jouw-naam.workers.dev/chat");urlInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);urlInput.setText(pref.getString("gateway_url",""));add(settings,urlInput);
        tokenInput=new EditText(this);tokenInput.setSingleLine(true);tokenInput.setTextSize(16);tokenInput.setHint(SecureToken.load(this).isEmpty()?"Toegangscode (minimaal 20 tekens)":"Toegangscode opgeslagen – leeg laten om te behouden");tokenInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);add(settings,tokenInput);
        Button store=button("🔐 Verbinding opslaan");add(settings,store);store.setOnClickListener(v->saveConnection());
        Button clear=button("🗑 Gesprek en opgeslagen toegangscode verwijderen");add(settings,clear);clear.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle("Alles wissen?")
            .setMessage("De lokale gespreksgeschiedenis en je servertoegangscode worden verwijderd.")
            .setNegativeButton("Annuleren",null).setPositiveButton("Wissen",(d,w)->{pref.edit().remove("turns").remove("gateway_url").remove("memory").apply();SecureToken.clear(this);while(turns.length()>0)turns.remove(0);urlInput.setText("");tokenInput.setText("");memoryInput.setText("");render();status.setText("Gespreksgeschiedenis en verbinding zijn verwijderd.");}).show());
        updateStatus();
    }
    private void render(){
        if(conversation==null)return;
        conversation.removeAllViews();
        if(turns.length()==0){TextView welcome=label("💕 Hallo, darling! Vertel me wat je bezighoudt. Hoe gaat het vandaag met je?",16);add(conversation,welcome);}
        for(int i=0;i<turns.length();i++){
            JSONObject t=turns.optJSONObject(i);if(t==null)continue;
            boolean marilyn="assistant".equals(t.optString("role"));
            TextView msg=label((marilyn?"💕 Marilyn: ":"🗣 Jij: ")+t.optString("content"),15);
            msg.setBackground(surface(marilyn?color(255,233,244):color(234,244,254)));
            add(conversation,msg);
        }
        transcript.post(()->transcript.fullScroll(View.FOCUS_DOWN));
    }
    private void restore(){
        try{JSONArray saved=new JSONArray(pref.getString("turns","[]"));
            for(int i=Math.max(0,saved.length()-24);i<saved.length();i++){JSONObject item=saved.optJSONObject(i);if(item!=null && ("user".equals(item.optString("role"))||"assistant".equals(item.optString("role"))))turns.put(item);}
        }catch(Exception ignored){}
    }
    private void addTurn(String role,String value){try {turns.put(new JSONObject().put("role",role).put("content",value));}catch(Exception ignored){}
        while(turns.length()>24)turns.remove(0);
        pref.edit().putString("turns",turns.toString()).apply();render();
    }
    private boolean connected(){return !pref.getString("gateway_url","").isEmpty() && !SecureToken.load(this).isEmpty();}
    private void updateStatus(){if(status==null)return;
        status.setText(pending?"⏳ Marilyn denkt na...":connected()?"🔐 Privéverbinding ingesteld. Klaar om te praten.":"⚙ Stel eerst de privé-AI-verbinding in. Zonder server geen vrij AI-gesprek.");
    }
    private void saveConnection(){
        String s=urlInput.getText().toString().trim();
        if(s.endsWith("/"))s+="chat";
        if(!s.endsWith("/chat")) {Toast.makeText(this,"Link moet eindigen op /chat",Toast.LENGTH_LONG).show();return;}
        try{Uri u=Uri.parse(s);if(!"https".equalsIgnoreCase(u.getScheme())||u.getHost()==null||u.getUserInfo()!=null||u.getQuery()!=null||u.getFragment()!=null)throw new Exception();}
        catch(Exception e){Toast.makeText(this,"Gebruik een geldige https://.../chat-link",Toast.LENGTH_LONG).show();return;}
        String secret=tokenInput.getText().toString().trim();
        if(!secret.isEmpty() && secret.length()<20){Toast.makeText(this,"Maak een toegangscode van minstens 20 tekens",Toast.LENGTH_LONG).show();return;}
        try{if(!secret.isEmpty())SecureToken.save(this,secret);}
        catch(Exception e){Toast.makeText(this,"Veilig opslaan is mislukt",Toast.LENGTH_LONG).show();return;}
        pref.edit().putString("gateway_url",s).putString("memory",memoryInput.getText().toString().trim().substring(0,Math.min(500,memoryInput.getText().toString().trim().length()))).apply();tokenInput.setText("");tokenInput.setHint("Toegangscode veilig opgeslagen");settingsOpen=false;settings.setVisibility(View.GONE);updateStatus();
        Toast.makeText(this,"Verbinding opgeslagen – probeer een vraag",Toast.LENGTH_LONG).show();
    }
    private void changeLanguage(boolean english){
        VoiceStyle.prefs(this).edit().putBoolean("voice_en",english).putInt("voice_index",0).apply();
        languageButton.setText(english?"🌎 Antwoorden: Engels · wissel naar Nederlands":"🇳🇱 Antwoorden: Nederlands · wissel naar Engels");
        if(ttsReady&&tts!=null)VoiceStyle.apply(this,tts);
        Toast.makeText(this,english?"Marilyn antwoordt voortaan in het Engels":"Marilyn antwoordt voortaan in het Nederlands",Toast.LENGTH_SHORT).show();
    }
    private void submitInput(){String text=message.getText().toString().trim();if(text.isEmpty())return;message.setText("");send(text);
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(message.getWindowToken(),0);
    }
    private void send(String text){
        if(pending){Toast.makeText(this,"Wacht even op Marilyns antwoord",Toast.LENGTH_SHORT).show();return;}
        if(!connected()){settingsOpen=true;settings.setVisibility(View.VISIBLE);updateStatus();Toast.makeText(this,"Eerst AI-verbinding instellen",Toast.LENGTH_LONG).show();return;}
        if(text.length()>1200){Toast.makeText(this,"Bericht is te lang (max. 1200 tekens)",Toast.LENGTH_LONG).show();return;}
        String lower=text.toLowerCase(Locale.ROOT);
        boolean dutch=lower.contains("spreek nederlands")||lower.contains("speak dutch")||lower.contains("in het nederlands")||lower.contains("in dutch")||lower.contains("ik begrijp het niet")||lower.contains("ik snap het niet")||lower.contains("wat zei je")||lower.contains("in nederlands");
        boolean english=lower.contains("spreek engels")||lower.contains("speak english")||lower.contains("in english")||lower.contains("in het engels")||lower.contains("naar het engels");
        if(dutch)changeLanguage(false);else if(english)changeLanguage(true);
        addTurn("user",text);
        pending=true;setButtons(false);updateStatus();
        final String url=pref.getString("gateway_url","");
        final String token=SecureToken.load(this);
        final String language=VoiceStyle.english(this)?"en":"nl";
        final String memory=pref.getString("memory","");
        JSONArray context=new JSONArray();
        for(int i=Math.max(0,turns.length()-12);i<turns.length();i++){
            JSONObject entry=turns.optJSONObject(i); if(entry==null)continue;
            try{
                String txt=entry.optString("content","");
                context.put(new JSONObject().put("role",entry.optString("role")).put("content",txt.substring(0,Math.min(1600,txt.length()))));
            }catch(Exception ignored){}
        }
        final String snapshot=context.toString();
        io.execute(()->{
            try {
                String reply=fetch(url,token,language,memory,snapshot);
                main.post(()->{if(dead)return;addTurn("assistant",reply);pending=false;setButtons(true);updateStatus();if(speakToggle.isChecked())say(reply);});
            }catch(Exception ex){
                String msg=ex.getMessage()==null?"Verbinding mislukt":ex.getMessage();
                main.post(()->{if(dead)return;pending=false;setButtons(true);updateStatus();Toast.makeText(this,"Marilyn: "+msg,Toast.LENGTH_LONG).show();status.setText("⚠ "+msg+". Probeer opnieuw.");});
            }
        });
    }
    private void setButtons(boolean enabled){sendButton.setEnabled(enabled);microphoneButton.setEnabled(enabled);questionButton.setEnabled(enabled);}
    private String fetch(String url,String secret,String lang,String memory,String history) throws Exception {
        HttpURLConnection con=null;
        try {
            con=(HttpURLConnection)new URL(url).openConnection();con.setRequestMethod("POST");con.setConnectTimeout(12000);con.setReadTimeout(55000);
            con.setDoOutput(true);con.setInstanceFollowRedirects(false);con.setRequestProperty("Content-Type","application/json; charset=utf-8");
            con.setRequestProperty("Authorization","Bearer "+secret);
            JSONObject data=new JSONObject();data.put("language",lang);data.put("memory",memory);data.put("messages",new JSONArray(history));
            byte[] body=data.toString().getBytes(StandardCharsets.UTF_8);con.setFixedLengthStreamingMode(body.length);
            try(OutputStream out=con.getOutputStream()){out.write(body);}
            int code=con.getResponseCode();
            if(code>=300&&code<400)throw new Exception("Doorverwijzing geweigerd: controleer je URL");
            InputStream stream=code>=200&&code<300?con.getInputStream():con.getErrorStream();
            if(stream==null)throw new Exception("Server gaf fout "+code);
            StringBuilder sb=new StringBuilder();try(BufferedReader br=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8))){
                String line;while((line=br.readLine())!=null&&sb.length()<15000)sb.append(line);
            }
            JSONObject payload=new JSONObject(sb.toString());
            if(code<200||code>=300)throw new Exception(payload.optString("error","Server gaf fout "+code));
            String result=payload.optString("reply","").trim();if(result.isEmpty())throw new Exception("Leeg antwoord van de AI");
            return result;
        }finally{if(con!=null)con.disconnect();}
    }
    private void say(String reply){
        if(!ttsReady||tts==null){queuedSpeech=reply;return;}
        VoiceStyle.apply(this,tts);
        tts.speak(reply,TextToSpeech.QUEUE_FLUSH,null,"marilyn_v7_chat");
    }
    private void talking(boolean on){
        if(!OverlayService.active)return;
        Intent i=new Intent(this,OverlayService.class);i.setAction(OverlayService.ACTION_SPEECH);i.putExtra("is_speaking",on);
        try{startService(i);}catch(Exception ignored){}
    }
    private void listen(){
        if(pending)return;
        try{
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            boolean recognizeEnglish=VoiceStyle.prefs(this).getBoolean("recognize_en",false);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,recognizeEnglish?"en-US":"nl-NL");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT,recognizeEnglish?"Talk to Marilyn":"Vertel Marilyn wat je wilt zeggen");
            startActivityForResult(i,REQUEST_SPEECH);
        }catch(Exception e){Toast.makeText(this,"Geen Android-spraakherkenning beschikbaar",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(request==REQUEST_SPEECH&&result==RESULT_OK&&data!=null){
            ArrayList<String> found=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if(found!=null&&!found.isEmpty())send(found.get(0));
        }
    }
    @Override protected void onDestroy(){dead=true;io.shutdownNow();if(tts!=null){tts.stop();tts.shutdown();tts=null;}talking(false);super.onDestroy();}
}
