package nl.marilyn.origineel;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.Normalizer;
import java.util.Locale;

/**
 * Small, deterministic, offline command parser. It does NOT translate arbitrary speech.
 * Language switching can repeat the last canned Marilyn phrase in the new language.
 */
final class SpokenCommand {
    static final class Outcome {
        final String answer;
        final int newPose;
        final boolean sizeChanged;
        final boolean languageChanged;
        Outcome(String answer, int newPose, boolean sizeChanged, boolean languageChanged) {
            this.answer = answer;
            this.newPose = newPose;
            this.sizeChanged = sizeChanged;
            this.languageChanged = languageChanged;
        }
    }

    private static String normal(String sentence) {
        if (sentence == null) return "";
        return Normalizer.normalize(sentence.toLowerCase(Locale.ROOT), Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .replaceAll("[^a-z0-9 ]", " ")
                .replaceAll("\\s+", " ").trim();
    }
    private static boolean has(String s, String... options) {
        for (String opt : options) if (s.contains(opt)) return true;
        return false;
    }

    private static String lastPhrase(Context c) {
        int last = VoiceStyle.prefs(c).getInt("last_spoken_pose", -1);
        if (last < 0 || last >= MarilynData.IMAGES.length) return "";
        return " " + VoiceStyle.line(c, last);
    }
    static void rememberPhrase(Context c, int pose) {
        VoiceStyle.prefs(c).edit().putInt("last_spoken_pose", MarilynData.validPose(pose)).apply();
    }

    static Outcome execute(Context context, String sentence) {
        final String s = normal(sentence);
        final SharedPreferences options = VoiceStyle.prefs(context);
        if (s.isEmpty()) return new Outcome("", -1, false, false);

        // Order matters: language requests take precedence over movement commands.
        boolean dutch = has(s,
                "spreek nederlands", "praat nederlands", "spreek nu nederlands",
                "praat nu nederlands", "nederlands spreken", "nederlands praten",
                "naar nederlands", "over op nederlands", "in het nederlands",
                "naar het nederlands", "voortaan nederlands",
                "in nederlands", "zeg het nederlands", "zeg dat nederlands",
                "speak dutch", "switch to dutch", "in dutch", "dutch please",
                "back to dutch", "change to dutch",
                "translate to dutch", "translate into dutch", "say that in dutch",
                "say it in dutch", "speak in dutch", "change to dutch");
        boolean english = has(s,
                "spreek engels", "praat engels", "spreek nu engels", "praat nu engels",
                "engels spreken", "engels praten", "naar engels", "over op engels",
                "in het engels", "naar het engels", "voortaan engels", "zeg het in engels", "say that in english",
                "speak english", "switch to english", "in english", "english please",
                "speak in english", "change to english", "back to english");
        boolean misunderstood = has(s,
                "wat zei je", "wat zeg je", "ik begrijp het niet", "ik snap het niet",
                "i don t understand", "i did not understand", "didn t understand");
        boolean repeat = has(s,
                "herhaal", "nog een keer", "repeat that", "say it again", "what did you say",
                "vertaal dat", "translate that");

        if (dutch || (!english && misunderstood)) {
            options.edit().putBoolean("voice_en", false).putInt("voice_index", 0).apply();
            return new Outcome("Natuurlijk! Vanaf nu spreek ik Nederlands." + lastPhrase(context), -1, false, true);
        }
        if (english) {
            options.edit().putBoolean("voice_en", true).putInt("voice_index", 0).apply();
            return new Outcome("Of course, darling! I'll speak English from now on." + lastPhrase(context), -1, false, true);
        }
        if (repeat) {
            String last = lastPhrase(context).trim();
            return new Outcome(last.isEmpty()
                    ? (VoiceStyle.english(context) ? "I don't have anything to repeat yet." : "Ik heb nog niets om te herhalen.")
                    : last, -1, false, false);
        }

        int next = -1;
        if (has(s,"zwaai", "zwaaien", "wave", "say hello")) next=3;
        else if (has(s,"spring", "jump")) next=4;
        else if (has(s,"naar rechts", "go right", "move right")) next=1;
        else if (has(s,"naar links", "go left", "move left")) next=2;
        else if (has(s,"verdriet", "teleurgesteld", "sad")) next=5;
        else if (has(s,"wacht", "wait")) next=6;
        else if (has(s,"denk", "thinking", "think")) next=7;
        else if (has(s,"beoord", "judge", "review")) next=8;
        else if (has(s,"rust", "relax", "rest")) next=0;
        if (next >= 0) {
            options.edit().putInt("pose", next).apply();
            rememberPhrase(context,next);
            return new Outcome(VoiceStyle.line(context,next), next, false, false);
        }

        if (has(s,"groter", "bigger", "larger")) {
            int now = MarilynData.validSize(options.getInt("size",100));
            options.edit().putInt("size", MarilynData.validSize(now+25)).apply();
            return new Outcome(VoiceStyle.english(context)
                    ? "There! A little bigger." : "Zo, ik ben een beetje groter.", -1, true, false);
        }
        if (has(s,"kleiner", "smaller")) {
            int now = MarilynData.validSize(options.getInt("size",100));
            options.edit().putInt("size", MarilynData.validSize(now-25)).apply();
            return new Outcome(VoiceStyle.english(context)
                    ? "There! A little smaller." : "Zo, ik ben een beetje kleiner.", -1, true, false);
        }
        return new Outcome(VoiceStyle.english(context)
                ? "I don't know that command yet. Try: speak Dutch, wave, or jump."
                : "Dat commando ken ik nog niet. Probeer: spreek Engels, zwaai of spring.", -1, false, false);
    }
    private SpokenCommand() {}
}
