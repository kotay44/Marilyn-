package nl.marilyn.origineel;

import android.content.Context;
import android.content.SharedPreferences;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** On-device TTS presets. Inspired by soft classic-film delivery; NOT an original Monroe recording. */
final class VoiceStyle {
    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("marilyn_options",Context.MODE_PRIVATE); }
    static boolean english(Context c) { return prefs(c).getBoolean("voice_en",true); }
    static boolean speakOnTap(Context c) { return prefs(c).getBoolean("speak_on_tap",true); }
    static String line(Context c,int pose) { return (english(c)?MarilynData.SAY_EN:MarilynData.SAY)[MarilynData.validPose(pose)]; }
    static int pitchPercent(Context c) { return Math.max(75,Math.min(140,prefs(c).getInt("voice_pitch",115))); }
    static int ratePercent(Context c) { return Math.max(65,Math.min(115,prefs(c).getInt("voice_rate",90))); }
    static List<Voice> candidates(Context c, TextToSpeech tts) {
        List<Voice> voices=new ArrayList<>();
        if(tts==null || tts.getVoices()==null) return voices;
        Locale required = english(c)?Locale.US:new Locale("nl","NL");
        for(Voice v : tts.getVoices()) {
            if(v==null || v.getLocale()==null) continue;
            if(!required.getLanguage().equals(v.getLocale().getLanguage())) continue;
            if(english(c) && !v.getLocale().getCountry().isEmpty() && !"US".equals(v.getLocale().getCountry())) continue;
            voices.add(v);
        }
        Collections.sort(voices,new Comparator<Voice>() {
            @Override public int compare(Voice a, Voice b){
                if(a.isNetworkConnectionRequired()!=b.isNetworkConnectionRequired())
                    return a.isNetworkConnectionRequired()?1:-1;
                if(a.getQuality()!=b.getQuality())return Integer.compare(b.getQuality(),a.getQuality());
                return a.getName().compareToIgnoreCase(b.getName());
            }
        });
        return voices;
    }
    static String apply(Context c, TextToSpeech tts) {
        if(tts==null)return "Spraakmodule wordt gestart...";
        boolean en=english(c);
        Locale loc=en?Locale.US:new Locale("nl","NL");
        int availability=tts.setLanguage(loc);
        if(availability==TextToSpeech.LANG_MISSING_DATA || availability==TextToSpeech.LANG_NOT_SUPPORTED)
            return "Taalstem ontbreekt. Installeer de stem bij Android Tekst-naar-spraak.";
        List<Voice> voices=candidates(c,tts);
        String label="Standaardstem "+(en?"Engels (VS)":"Nederlands");
        if(!voices.isEmpty()) {
            int index=Math.floorMod(prefs(c).getInt("voice_index",0),voices.size());
            Voice chosen=voices.get(index);
            if(tts.setVoice(chosen)==TextToSpeech.SUCCESS)
                label=chosen.getName()+(chosen.isNetworkConnectionRequired()?" (internet nodig)":" (offline)");
        }
        tts.setPitch(pitchPercent(c)/100f);
        tts.setSpeechRate(ratePercent(c)/100f);
        return label;
    }
    private VoiceStyle() {}
}
