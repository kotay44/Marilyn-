package nl.marilyn.origineel;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Build;
import android.speech.RecognizerIntent;
import android.widget.Toast;
import java.util.ArrayList;

/** Opens Android's own microphone UI after a deliberate long-press on the floating figure.
 * No always-on microphone and no recording permission needed by this app.
 */
public final class VoiceCommandActivity extends Activity {
    private static final int SPEECH_REQUEST = 70;
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        if (saved == null) {
            try {
                boolean englishInput = VoiceStyle.prefs(this).getBoolean("recognize_en", false);
                Intent listen = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                listen.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                listen.putExtra(RecognizerIntent.EXTRA_LANGUAGE, englishInput ? "en-US" : "nl-NL");
                listen.putExtra(RecognizerIntent.EXTRA_PROMPT, englishInput
                        ? "Say: Marilyn, speak Dutch / speak English"
                        : "Zeg: Marilyn, spreek Nederlands / spreek Engels");
                startActivityForResult(listen, SPEECH_REQUEST);
            } catch (Exception e) {
                Toast.makeText(this, "Spraakherkenning is niet beschikbaar.", Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SPEECH_REQUEST) {
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (matches != null && !matches.isEmpty()) {
                    SpokenCommand.Outcome out = SpokenCommand.execute(this, matches.get(0));
                    Intent command = new Intent(this, OverlayService.class);
                    command.setAction(OverlayService.ACTION_VOICE_RESULT);
                    command.putExtra("reply", out.answer);
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(command);
                    else startService(command);
                }
            }
            finish();
        }
    }
}
