# Marilyn 3D in de stijl van jouw 2D-figuurtje — v8 testbouw

Deze testversie is gebaseerd op Marilyn v7. De bestaande OpenGL ES 2.0-meshes,
rotatie, beweging, transparante versleepbare Android-overlay en conversatiebasis
blijven aanwezig. De voorkeur staat nu op het gezicht uit `marilyn_7.png`, exact
de figuur die je in de screenshot liet zien. De originele 2D-tekeningen blijven
beschikbaar; een knop wisselt tussen de drie gezichtsstanden:
1. Cartoon-gezicht uit de 2D-tekening (standaard)
2. Filmgezicht uit de eerdere video
3. Eenvoudig getekend 3D-gezicht

**Eerlijke beperking:** dit is een verbeterde volumetrische testversie, geen
volledig nieuw professioneel gesculpt/gerigged 3D-karakter. De voorkant gebruikt
jouw bestaande 2D-kopafbeelding als textuur op een gebogen oppervlak vóór een
3D-hoofd. Van opzij en achteren blijven de volumetrische onderdelen een
artistieke benadering. Het oorspronkelijke plaatje is maar 104×201 pixels;
vergroting voegt geen echte details toe. Anatomisch identieke zij- en achterkant
vereisen een zelfstandig ontworpen compleet 3D-model met UV-texturen en rig.
De mondbeweging is nog geen fonetisch correcte lipsynchronisatie.

De Android applicationId is veranderd in `nl.marilyn.stijl3d`, en de app heet
`Marilyn 3D`, zodat deze testversie naast de bestaande `Marilyn Assistant`
geïnstalleerd kan worden zonder de eerder gemelde ondertekeningsconflicten.

AI-conversatie via `backend/worker.js` werkt alleen na eigen configuratie van
een Cloudflare Worker en API-toegang; sleutels horen nooit in GitHub thuis.
De stem is Android TTS, geen gekloonde originele filmstem. Zie v7 README voor
privacy- en gebruiksvoorwaarden.

## GitHub bouwen vanaf telefoon
- Upload `Marilyn-v8-3D-in-2D-stijl.zip` naar de hoofdmap van de repository
- Upload `Marilyn-v8-3D-build.yml` naar `.github/workflows`
- Open Actions → Marilyn v8 - 3D in 2D stijl → Run workflow → main
- Na succes, download artifact `Marilyn-v8-3D-APK` en pak `app-debug.apk` uit.

Deze bestanden zijn lokaal op syntaxis en archiefintegriteit gecontroleerd,
maar niet in Android SDK gebouwd of op een telefoon uitgevoerd. Gebruik GitHub
Actions voor de daadwerkelijke compiler- en installatietest.
