# Marilyn Assistant – originele cartoon – Android v1.1

## Wat werkt er in deze broncode?
- De negen originele poses uit het door jou aangeleverde filmpje (transparante PNG's).
- Native Android animaties: zweven, zwaaien, rennen, springen en rustige bewegingen.
- Knoppen in de app, vergroting 75–200%, automatisch houdingen wisselen.
- Nederlandse tekst-naar-spraak via de geïnstalleerde Android-spraakdienst.
- Eenvoudige spraakopdrachten via Androids spraakherkenningsvenster (indien beschikbaar).
- Optionele zwevende Marilyn over andere apps, versleepbaar, met ×2-knop en stopknop.

## Wat is deze versie NIET?
- Geen echt vrij draaibaar 3D-mesh, maar bewegende **2.5D**-beelden.
- Geen geïntegreerde ChatGPT-API of vrije AI-gesprekken.
- Geen belofte dat AVG of een andere virusscanner deze ongeteste APK accepteert.

## Privacy
- Geen INTERNET-machtiging.
- Geen WebView en geen JavaScript-bridge.
- Geen directe microfoon-, camera-, contacten- of sms-machtiging.
- Overlaymachtiging wordt alleen gebruikt nadat de gebruiker dat uitdrukkelijk kiest.
- Spraakherkenning verloopt via de beschikbare spraakdienst van het toestel en kan bij die externe dienst een netwerkverbinding gebruiken.
- Een zichtbare foreground-notificatie geeft aan wanneer Marilyn boven apps actief is.

## Bouwen
Uitpakken, map `android` openen als project in Android Studio met Java 17 en Android SDK 35, of GitHub Actions gebruiken met Gradle 8.10.2.
In de bestaande GitHub repository kan de nieuw geüploade ZIP worden uitgepakt en uitgevoerd via de opgegeven workflow.

## Veiligheid / eerder AVG-alarm
De eerdere Marilyn-APK werd door AVG als mogelijke malware aangemerkt.
Deze versie vermijdt de oude JavaScript-WebView-koppeling, maar is niet onafhankelijk op malware onderzocht en heeft nog steeds een gevoelige optionele overlayfunctie.
Bij een malwarewaarschuwing: niet openen en geen beveiliging uitschakelen. Laat de APK onderzoeken door de antivirusleverancier.
Debug-builds zijn alleen bedoeld voor eigen testen; voor publieke distributie moet een release-build worden ondertekend, beoordeeld en getest.
