package nl.marilyn.origineel;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ImageView;

public final class MarilynMotion {
    private static final int[] DRAWABLE = Pose.DRAWABLES;
    private MarilynMotion() { }
    public static void show(ImageView image, int requested) {
        int pose = Pose.clamp(requested);
        Object previous = image.getTag();
        if (previous instanceof ObjectAnimator) ((ObjectAnimator) previous).cancel();
        image.setTranslationX(0f); image.setTranslationY(0f); image.setRotation(0f);
        image.setImageResource(DRAWABLE[pose]);
        float d = image.getResources().getDisplayMetrics().density;
        float x=0f, y=-5f*d, rot=2f;
        long ms=1350;
        switch (pose) {
            case 1: x=22f*d; y=-9f*d; rot=3f; ms=570; break;
            case 2: x=-22f*d; y=-9f*d; rot=-3f; ms=570; break;
            case 3: rot=6f; ms=670; break;
            case 4: y=-48f*d; rot=0f; ms=510; break;
            case 5: y=2f*d; rot=-2f; ms=1450; break;
            case 6: rot=1f; ms=1900; break;
            case 7: rot=-3f; ms=1700; break;
            case 8: rot=3f; ms=1600; break;
        }
        ObjectAnimator a = ObjectAnimator.ofPropertyValuesHolder(image,
            PropertyValuesHolder.ofFloat("translationX", 0f,x),
            PropertyValuesHolder.ofFloat("translationY",0f,y),
            PropertyValuesHolder.ofFloat("rotation",0f,rot));
        a.setInterpolator(new AccelerateDecelerateInterpolator());
        a.setRepeatCount(ObjectAnimator.INFINITE);
        a.setRepeatMode(ObjectAnimator.REVERSE);
        a.setDuration(ms);
        image.setTag(a);
        a.start();
    }
    public static void stop(ImageView image) {
        Object o=image.getTag();
        if (o instanceof ObjectAnimator) ((ObjectAnimator)o).cancel();
        image.setTag(null);
    }
}
