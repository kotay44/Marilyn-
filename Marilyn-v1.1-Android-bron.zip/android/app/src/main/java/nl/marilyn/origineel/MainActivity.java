package nl.marilyn.origineel;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int SPEECH_REQUEST = 40;
    private ImageView marilyn;
    private FrameLayout stage;
    private TextView status;
    private SeekBar sizeBar;
    private Speaker speaker;
    private int currentPose=0;
    private boolean auto=false;
    private final android.os.Handler handler=new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable autoStep = new Runnable() {
        @Override public void run() {
            if (!auto) return;
            selectPose((currentPose+1)%9);
            handler.postDelayed(this,2200);
        }
    };
    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        speaker=new Speaker(this);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(255,239,248));
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(16),dp(16),dp(16),dp(32));
        scroll.addView(layout);
        TextView title = text("💕 Marilyn Assistant",26,true);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);
        TextView subtitle=text("Originele cartoon uit jouw filmpje • 9 houdingen • offline beelden",13,false);
        subtitle.setGravity(Gravity.CENTER); layout.addView(subtitle);

        stage = new FrameLayout(this);
        GradientDrawable background=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{0xFFFFFCFE,0xFFF9DCEB});
        background.setCornerRadius(dp(24));
        stage.setBackground(background);
        stage.setClipChildren(false);
        stage.setClipToPadding(false);
        LinearLayout.LayoutParams stageLp=new LinearLayout.LayoutParams(-1,dp(360));
        stageLp.setMargins(0,dp(12),0,dp(16));
        layout.addView(stage,stageLp);
        marilyn=new ImageView(this);
        marilyn.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams imageLp = new FrameLayout.LayoutParams(dp(212),dp(305),Gravity.CENTER);
        stage.addView(marilyn,imageLp);
        marilyn.setOnClickListener(v -> { stopAuto(); selectPose(3); say("Hallo! Wat leuk dat je er bent."); });
        status=text("Tik op een houding om Marilyn te laten bewegen.",14,false);
        status.setGravity(Gravity.CENTER);
        layout.addView(status);
        GridLayout poses=new GridLayout(this);
        poses.setColumnCount(3);
        LinearLayout.LayoutParams gridLp=new LinearLayout.LayoutParams(-1,-2);
        gridLp.setMargins(0,dp(12),0,dp(10));
        layout.addView(poses,gridLp);
        String[] icons={"🌸","➡️","⬅️","👋","✨","🥺","💭","🤔","💕"};
        for (int i=0;i<9;i++) {
            final int pos=i;
            Button btn=button(icons[i]+"\n"+Pose.NAMES[i]);
            btn.setTextSize(12f);
            btn.setMinHeight(dp(60));
            GridLayout.LayoutParams p=new GridLayout.LayoutParams();
            p.width=0; p.height=dp(70);
            p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);
            p.setMargins(dp(2),dp(3),dp(2),dp(3));
            poses.addView(btn,p);
            btn.setOnClickListener(v -> {stopAuto();selectPose(pos);});
        }
        TextView sizeLabel=text("Grootte Marilyn (75% – 200%)",14,true);layout.addView(sizeLabel);
        sizeBar=new SeekBar(this);sizeBar.setMax(125);sizeBar.setProgress(25);
        layout.addView(sizeBar,new LinearLayout.LayoutParams(-1,dp(45)));
        sizeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s,int value,boolean user) { resize(value+75); }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        addButton(layout,"×2 groter",() -> sizeBar.setProgress(125));
        addButton(layout,"▶ Automatisch bewegen / stoppen",() -> { auto=!auto;handler.removeCallbacks(autoStep); if(auto)handler.post(autoStep); else selectPose(0); });
        addButton(layout,"🔊 Marilyn laten praten",() -> say(Pose.PHRASES[currentPose]));
        addButton(layout,"🎙 Spreek een opdracht in",this::startRecognition);
        addButton(layout,"💕 Zwevende Marilyn boven andere apps",this::startOverlay);
        addButton(layout,"✖ Zwevende Marilyn stoppen",() -> stopService(new Intent(this,OverlayService.class)));
        TextView notice=text("Deze versie gebruikt native Android-weergave en bevat geen internettoegang of JavaScript. Spraakherkenning gebruikt de spraakdienst van je telefoon. Het zwevende venster is optioneel. Bij een antiviruswaarschuwing: niet openen en niet de beveiliging uitschakelen.",12,false);
        notice.setPadding(dp(4),dp(14),dp(4),dp(8));layout.addView(notice);
        setContentView(scroll);
        selectPose(0);
    }
    private TextView text(String value,int size,boolean bold) {
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);
        t.setTextColor(0xFF743F5B);t.setPadding(dp(4),dp(7),dp(4),dp(7));
        if(bold)t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    private Button button(String title) {
        Button b=new Button(this);b.setAllCaps(false);b.setText(title);
        b.setTextColor(0xFF612947);b.setTextSize(15f);return b;
    }
    private void addButton(LinearLayout holder,String label,Runnable action) {
        Button b=button(label);holder.addView(b,new LinearLayout.LayoutParams(-1,dp(54)));
        b.setOnClickListener(v->action.run());
    }
    private void resize(int percent) {
        if(marilyn==null || stage==null)return;
        float scale=percent/100f;
        FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)marilyn.getLayoutParams();
        p.width=dp(212*scale);p.height=dp(305*scale);
        marilyn.setLayoutParams(p);
        ViewGroup.LayoutParams frame=stage.getLayoutParams();
        if(frame!=null){frame.height=dp(360*scale);stage.setLayoutParams(frame);}
        if(status!=null)status.setText("Marilyn: "+Pose.NAMES[currentPose]+" · grootte "+percent+"%");
    }
    private void selectPose(int pose) {
        currentPose=Pose.clamp(pose);
        MarilynMotion.show(marilyn,currentPose);
        if(status!=null) status.setText("Marilyn: "+Pose.NAMES[currentPose]);
    }
    private void stopAuto(){auto=false;handler.removeCallbacks(autoStep);}
    private void say(String words){
        selectPose(3);
        if(!speaker.speak(words))Toast.makeText(this,"Nederlandse spraakstem wordt geladen of ontbreekt.",Toast.LENGTH_LONG).show();
    }
    private void startRecognition() {
        stopAuto();
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"nl-NL");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Zeg bijvoorbeeld: Marilyn zwaai, spring of denk");
        try { startActivityForResult(i,SPEECH_REQUEST); }
        catch(ActivityNotFoundException e){ Toast.makeText(this,"Geen spraakherkenning beschikbaar op deze telefoon.",Toast.LENGTH_LONG).show(); }
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request!=SPEECH_REQUEST || result!=RESULT_OK || data==null)return;
        ArrayList<String> results=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if(results==null || results.isEmpty())return;
        String words=results.get(0).toLowerCase(Locale.forLanguageTag("nl-NL"));
        if(words.contains("spring")){selectPose(4);speaker.speak("Daar ga ik!");}
        else if(words.contains("zwaai")||words.contains("hallo")){selectPose(3);speaker.speak("Hallo!");}
        else if(words.contains("rechts")){selectPose(1);}
        else if(words.contains("links")){selectPose(2);}
        else if(words.contains("denk")){selectPose(7);}
        else if(words.contains("wacht")){selectPose(6);}
        else if(words.contains("verdriet")||words.contains("teleurgesteld")){selectPose(5);}
        else if(words.contains("rust")){selectPose(0);}
        else {status.setText("Ik hoorde: "+words+". Probeer: zwaai, spring, links of rechts.");speaker.speak("Dat commando ken ik nog niet.");}
    }
    private void startOverlay(){
        if(!Settings.canDrawOverlays(this)) {
            Toast.makeText(this,"Geef alleen toestemming als je Marilyn boven andere apps wilt zien.",Toast.LENGTH_LONG).show();
            Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));
            startActivity(i);return;
        }
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},12);
            Toast.makeText(this,"Tik na de toestemmingsvraag nogmaals op 'Zwevende Marilyn'.",Toast.LENGTH_LONG).show();
            return;
        }
        try {
            startForegroundService(new Intent(this,OverlayService.class));
            moveTaskToBack(true);
        } catch(Exception e){Toast.makeText(this,"Zwevend venster kon niet starten: "+e.getClass().getSimpleName(),Toast.LENGTH_LONG).show();}
    }
    @Override protected void onDestroy(){stopAuto();if(marilyn!=null)MarilynMotion.stop(marilyn);if(speaker!=null)speaker.shutdown();super.onDestroy();}
}
