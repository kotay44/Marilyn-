package nl.marilyn.origineel;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private static final String CHANNEL="marilyn_visible_overlay";
    private WindowManager manager;
    private LinearLayout panel;
    private WindowManager.LayoutParams params;
    private ImageView image;
    private Speaker speaker;
    private int pose=0;
    private boolean large=false;
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    @Override public void onCreate(){super.onCreate();speaker=new Speaker(this);}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(!Settings.canDrawOverlays(this)) {stopSelf();return START_NOT_STICKY;}
        if(panel!=null) return START_STICKY;
        beginForeground();
        makeOverlay();
        return START_STICKY;
    }
    private void beginForeground(){
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Marilyn zichtbaar",NotificationManager.IMPORTANCE_LOW));
        Intent open=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification note=new Notification.Builder(this,CHANNEL)
            .setContentTitle("Marilyn Cartoon")
            .setContentText("Zwevende Marilyn is zichtbaar. Open om haar te stoppen.")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(pi).setOngoing(true).build();
        if(Build.VERSION.SDK_INT>=34)startForeground(201,note,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(201,note);
    }
    private Button mini(String caption,Runnable callback){
        Button b=new Button(this);b.setAllCaps(false);b.setText(caption);b.setTextSize(12);
        b.setPadding(0,0,0,0);
        b.setMinWidth(0);b.setMinimumWidth(0);b.setMinHeight(dp(35));
        b.setOnClickListener(v -> callback.run());return b;
    }
    private void makeOverlay(){
        manager=(WindowManager)getSystemService(WINDOW_SERVICE);
        panel=new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg=new GradientDrawable();bg.setColor(0xEFFFF5FA);bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1),0xFFEEB8D3);panel.setBackground(bg);
        LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);bar.setGravity(Gravity.CENTER_VERTICAL);
        panel.addView(bar,new LinearLayout.LayoutParams(-1,dp(46)));
        TextView grip=new TextView(this);grip.setText("⋮⋮");grip.setTextSize(19);grip.setTextColor(Color.rgb(137,65,99));
        grip.setGravity(Gravity.CENTER);
        bar.addView(grip,new LinearLayout.LayoutParams(0,-1,1));
        bar.addView(mini("👋",() -> changePose(3)),new LinearLayout.LayoutParams(0,dp(42),1));
        bar.addView(mini("🔊",() -> {changePose(3);speaker.speak("Hallo! Ik ben Marilyn.");}),new LinearLayout.LayoutParams(0,dp(42),1));
        bar.addView(mini("×2",this::toggleSize),new LinearLayout.LayoutParams(0,dp(42),1));
        bar.addView(mini("✕",this::stopSelf),new LinearLayout.LayoutParams(0,dp(42),1));
        image=new ImageView(this);image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        panel.addView(image,new LinearLayout.LayoutParams(-1,0,1));
        image.setOnClickListener(v -> changePose((pose+1)%9));
        params=new WindowManager.LayoutParams(dp(178),dp(290),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START;params.x=dp(20);params.y=dp(120);
        try{manager.addView(panel,params);}catch(Exception ex){panel=null;stopSelf();return;}
        grip.setOnTouchListener(new View.OnTouchListener(){
            private float downX,downY;private int oldX,oldY;
            @Override public boolean onTouch(View v,MotionEvent e){
                switch(e.getAction()){
                    case MotionEvent.ACTION_DOWN:downX=e.getRawX();downY=e.getRawY();oldX=params.x;oldY=params.y;return true;
                    case MotionEvent.ACTION_MOVE:params.x=oldX+Math.round(e.getRawX()-downX);
                        params.y=oldY+Math.round(e.getRawY()-downY);
                        if(manager!=null&&panel!=null) manager.updateViewLayout(panel,params);return true;
                    default:return true;
                }
            }
        });
        changePose(0);
    }
    private void changePose(int n){pose=Pose.clamp(n);if(image!=null)MarilynMotion.show(image,pose);}
    private void toggleSize(){
        large=!large;
        if(params==null||panel==null||manager==null)return;
        int maxWidth=getResources().getDisplayMetrics().widthPixels-dp(12);
        int maxHeight=getResources().getDisplayMetrics().heightPixels-dp(120);
        params.width=large?Math.min(dp(356),maxWidth):dp(178);
        params.height=large?Math.min(dp(580),maxHeight):dp(290);
        manager.updateViewLayout(panel,params);
    }
    @Override public void onDestroy(){
        if(image!=null)MarilynMotion.stop(image);
        if(manager!=null&&panel!=null){try{manager.removeView(panel);}catch(Exception ignore){}}
        panel=null; image=null;
        if(speaker!=null)speaker.shutdown();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
}
