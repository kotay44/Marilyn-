package nl.marilyn.origineel;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import java.util.Locale;

public final class Speaker {
    private TextToSpeech tts;
    private boolean ready=false;
    public Speaker(Context context) {
        tts=new TextToSpeech(context.getApplicationContext(), code -> {
            if(code==TextToSpeech.SUCCESS && tts!=null) {
                int result=tts.setLanguage(Locale.forLanguageTag("nl-NL"));
                ready=(result!=TextToSpeech.LANG_MISSING_DATA && result!=TextToSpeech.LANG_NOT_SUPPORTED);
                tts.setSpeechRate(0.93f);
                tts.setPitch(1.05f);
            }
        });
    }
    public boolean speak(String msg) {
        if(!ready || tts==null) return false;
        tts.speak(msg,TextToSpeech.QUEUE_FLUSH,null,"marilyn");
        return true;
    }
    public void shutdown() { if(tts!=null) { tts.stop(); tts.shutdown(); tts=null; } ready=false; }
}
