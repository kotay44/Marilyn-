package nl.marilyn.origineel;

public final class Pose {
    public static final int[] DRAWABLES = {
        R.drawable.marilyn_1, R.drawable.marilyn_2, R.drawable.marilyn_3,
        R.drawable.marilyn_4, R.drawable.marilyn_5, R.drawable.marilyn_6,
        R.drawable.marilyn_7, R.drawable.marilyn_8, R.drawable.marilyn_9
    };
    public static final String[] NAMES = {
        "Rustig", "Naar rechts", "Naar links", "Zwaaien", "Springen",
        "Teleurgesteld", "Wachten", "Denken", "Beoordelen"
    };
    public static final String[] PHRASES = {
        "Hoi, wat leuk om je te zien!", "Kijk, ik ga naar rechts.",
        "En nu ga ik naar links.", "Hallo daar!", "Jippie!",
        "Ach, dat is jammer.", "Ik wacht gezellig op je.",
        "Even nadenken hoor.", "Wat vind jij ervan?"
    };
    private Pose() { }
    public static int clamp(int p) { return Math.max(0, Math.min(8, p)); }
}
