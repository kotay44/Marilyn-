# Marilyn Assistant 7.0 – FILMREFERENTIE IN 3D (prototype)

Een echt volumetrisch OpenGL ES 2.0-personage, gemaakt op basis van de v6-app en de
gezichtsreferentie van een frame op 00:55 uit jouw geüploade filmfragment.

## NIEUW IN v7
* Een GEBOGEN 3D-gezichtsvlak met een texture die uit het ingestuurde filmbeeld
  is gehaald, in plaats van alleen bolvormige tekenfilmogen. Het 3D-hoofd draait.
* Hoofd kleiner en proporties minder kinderlijk; haarkleur en meer haarlokken.
* 3D-figuur blijft transparant en verplaatsbaar via de bestaande Android-overlay.
* Optioneel wisselen: filmgezicht ↔ getekend 3D-gezicht; bestaande 2D eveneens.
* Vrije NL/EN AI-gesprekken, vragen, adviezen, beperkte lokale context, via
  de bestaande beveiligde v6 Cloudflare Worker als jij die zelf configureert.
* NIEUW: optionele begroeting bij ontgrendelen; standaard UIT. Alleen wanneer
  Marilyn als service draait, eens per >= 3 uur, tussen 09:00 en 22:00,
  met wisselende vragen. Je kunt dit in de hoofdapp in- en uitschakelen.

## WAT DIT (NOG) NIET IS
Dit is een 3D-prototype, niet een fotorealistische, anatomisch exacte digitale
reconstructie van Marilyn Monroe. Het gezicht is een foto TEXTUUR op een gebogen
3D-vlak vóór een bestaand handgemaakt 3D-hoofd. Het haar, jurk en lichaam zijn
nog gestileerde 3D-meshes; de gefilmde gezichtsexpressie is niet volledig
3D-gereconstrueerd. Het beeldfragment is een verticale schermopname met
beperkte filmresolutie. De mondanimatie is NIET fonetisch lip-sync.

Er is GEEN stemkloon van Marilyn Monroe ingebouwd. De app gebruikt de
EN/NL-spraakstemmen die op je Samsung beschikbaar zijn. Voor een echt
geïndividualiseerde filmstem zijn gelicentieerde stemdata, een geschikte
TTS-provider en zorgvuldige integratie nodig; dit is niet getest of ingebouwd.

Spontane begroetingen zijn korte VOORAF GESCHREVEN zinnen (geen autonome
AI-initiatieven) en ze luisteren niet mee. De conversatieknop is met AI als
je een EIGEN server en API hebt geconfigureerd. Zonder die koppeling zijn
vrije AI-gesprekken niet beschikbaar. ChatGPT Plus bevat niet automatisch
OpenAI API-credits. De oude app gebruikt dezelfde Android applicationId:
`nl.marilyn.origineel`.

## APK BOUWEN – TWEE BESTANDEN VIA GITHUB OP TELEFOON
De oorspronkelijke alles-in-een-workflow was groter dan 500 KB; daarom kan
GitHub die niet als workflow verwerken. Gebruik voortaan twee losse bestanden.

1. Upload `Marilyn-v7-Android-broncode.zip` in de HOOFDMAP (`main`) van jouw
   GitHub repository. Laat dit bestand ingepakt; GitHub pakt het later zelf uit.
2. Upload `Marilyn-v7-3D-workflow-KLEIN.yml` in `.github/workflows`.
3. Verwijder de oude, te grote `Marilyn-v7-1-bestand-GitHub-Actions.yml`
   uit `.github/workflows` (die is niet meer nodig).
4. Open Actions > Marilyn v7 - Filmgezicht 3D (hersteld) > Run workflow.
5. Na groene, geslaagde uitvoering: open Artifacts >
   `Marilyn-v7-filmgezicht-APK`, download het ZIP-artifact en pak
   `app-debug.apk` uit om te installeren.

LET OP: het APK-bestand wordt pas gemaakt wanneer GitHub de workflow uitvoert;
een validatie van de ZIP bewijst op zichzelf niet dat Android-build zal slagen.
Voor de app en installatie gelden dezelfde waarschuwingen voor het vervangen
van een oudere versie en mogelijk verlies van lokaal opgeslagen gegevens.

## ALTERNATIEF – LOSSE BRONCODE
Je kunt het ZIP-archief ook zelf uitpakken om de bronbestanden te inspecteren
of lokaal met Android Studio te bouwen. Het pakket bevat ook een standaard
`.github/workflows/build.yml`, maar de hierboven genoemde kleine workflow
bouwt rechtstreeks uit het ZIP-archief op GitHub.

## AI (ALS JE VRIJ WILT PRATEN)
De bestaande servercode staat in `backend/worker.js`. Volg de v6-instructies:
Cloudflare Worker met Secrets OPENAI_API_KEY en MARILYN_ACCESS_TOKEN. Maak
NOOIT een screenshot of publieke commit met je secrets.

## ANDROID EN TESTSTATUS
minSdk 26, targetSdk 35, OpenGL ES 2.0, Java 17.
De bestanden, PNG-afmetingen, shader-programmatekst en Java-brontekst zijn
hier gecontroleerd. Er is GEEN Android SDK of Gradle-installatie in deze
werkomgeving. De APK is daardoor hier niet echt gecompileerd/uitgevoerd.
De GitHub Action doet het echte compileerwerk en kan compile-/runtimefouten
signaleren. Als de bouw faalt, stuur de eerste foutregels uit Actions terug.

## RECHTEN EN PRIVACY
De gebruikte face-textuur komt uit JOUW aangeleverde filmclip. Voor privé
experimenten; verspreid of verkoop dit pakket niet zonder rechten te toetsen
op filmbeelden en op het gebruik van naam, beeltenis en stemgelijkenis.
De zwevende service luistert niet voortdurend. Voor getypte of gesproken
AI-vragen worden gebruikersinhoud en context naar je ingestelde Worker/API
verzonden. Voor persoonlijke medische/financiële gegevens: wees terughoudend.
