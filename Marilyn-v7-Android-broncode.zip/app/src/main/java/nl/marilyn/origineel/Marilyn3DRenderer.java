package nl.marilyn.origineel;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.opengl.GLUtils;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.content.Context;
import android.os.SystemClock;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.ArrayDeque;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * Procedural THREE-DIMENSIONAL cartoon avatar. The head, dress, arms, legs, eyes,
 * hair and face are volumetric meshes that can be viewed from any angle.
 * Artistic interpretation of the original Marilyn reference frames: exact
 * frame-by-frame likeness would require a hand-sculpted and textured model.
 */
public final class Marilyn3DRenderer implements GLSurfaceView.Renderer {
    volatile int pose = 0;
    volatile boolean filmFace = true;
    private final Context context;
    Marilyn3DRenderer(Context c) { this.context = c.getApplicationContext(); }
    volatile float yaw = 0;
    volatile long waveUntil = 0L;
    volatile boolean speaking = false;

    private static final float[] SKIN = rgb(240, 192, 164), SKIN_SHADE = rgb(223, 171, 144);
    private static final float[] HAIR = rgb(224, 199, 156), HAIR_LIGHT = rgb(247, 222, 178);
    private static final float[] HAIR_DARK = rgb(165, 133, 96), WHITE = rgb(252, 250, 247);
    private static final float[] DRESS = rgb(250, 249, 243), PLEAT = rgb(225, 222, 219);
    private static final float[] EYE_WHITE = rgb(255, 255, 246), BLUE = rgb(68, 154, 175);
    private static final float[] PUPIL = rgb(28, 46, 63), LASH = rgb(85, 64, 53);
    private static final float[] LIP = rgb(183, 64, 77), BLUSH = rgb(241, 160, 145);
    private static final float[] SOLE = rgb(238, 221, 202);
    private final float[] proj = new float[16], view = new float[16];
    private final float[] vp = new float[16], matrix = new float[16], combined = new float[16];
    private final ArrayDeque<float[]> stack = new ArrayDeque<>();
    private Mesh sphere, cylinder, skirt;
    private int program, aPosition, aNormal, uMvp, uModel, uColor;
    private int photoProgram, photoTex, pPosition, pUv, uPhotoMvp, uPhotoTex;
    private FloatBuffer photoVerts; private ShortBuffer photoIndices; private int photoCount;
    private long timeStart;

    private static float[] rgb(int r, int g, int b) { return new float[]{r / 255f, g / 255f, b / 255f}; }
    private static class Mesh {
        final FloatBuffer vertex;
        final ShortBuffer index;
        final int count;
        Mesh(float[] array, short[] order) {
            ByteBuffer vb = ByteBuffer.allocateDirect(array.length * 4).order(ByteOrder.nativeOrder());
            vertex = vb.asFloatBuffer(); vertex.put(array); vertex.position(0);
            ByteBuffer ib = ByteBuffer.allocateDirect(order.length * 2).order(ByteOrder.nativeOrder());
            index = ib.asShortBuffer(); index.put(order); index.position(0);
            count = order.length;
        }
    }
    private static class Geometry {
        final float[] xyz;
        final short[] triangles;
        Geometry(int vertices, int triangleIndices) { xyz = new float[vertices * 6]; triangles = new short[triangleIndices]; }
    }
    private static Mesh roundMesh(int vertical, int radial) {
        Geometry g = new Geometry((vertical + 1) * (radial + 1), vertical * radial * 6);
        int p = 0, idx = 0;
        for (int i = 0; i <= vertical; i++) {
            double lat = -Math.PI/2 + Math.PI*i/vertical;
            float h = (float)Math.sin(lat), ring = (float)Math.cos(lat);
            for (int j = 0; j <= radial; j++) {
                float lon = (float)(2*Math.PI*j/radial);
                float x = ring*(float)Math.sin(lon), z = ring*(float)Math.cos(lon);
                g.xyz[p++] = x; g.xyz[p++] = h; g.xyz[p++] = z;
                g.xyz[p++] = x; g.xyz[p++] = h; g.xyz[p++] = z;
            }
        }
        for (int i=0; i<vertical; i++) for (int j=0;j<radial;j++) {
            short a=(short)(i*(radial+1)+j), b=(short)(a+radial+1);
            g.triangles[idx++]=a; g.triangles[idx++]=b; g.triangles[idx++]=(short)(a+1);
            g.triangles[idx++]=(short)(a+1); g.triangles[idx++]=b; g.triangles[idx++]=(short)(b+1);
        }
        return new Mesh(g.xyz,g.triangles);
    }
    private static Mesh cylinderMesh(int radial) {
        Geometry g = new Geometry((radial+1)*2,radial*6);
        int p=0, idx=0;
        for (int y=0;y<2;y++) for (int j=0;j<=radial;j++) {
            float a=(float)(2*Math.PI*j/radial),x=(float)Math.sin(a),z=(float)Math.cos(a);
            g.xyz[p++]=x;g.xyz[p++]=y==0?-1f:1f;g.xyz[p++]=z;
            g.xyz[p++]=x;g.xyz[p++]=0f;g.xyz[p++]=z;
        }
        for (int j=0;j<radial;j++) {
            short a=(short)j,b=(short)(radial+1+j);
            g.triangles[idx++]=a;g.triangles[idx++]=(short)(a+1);g.triangles[idx++]=b;
            g.triangles[idx++]=(short)(a+1);g.triangles[idx++]=(short)(b+1);g.triangles[idx++]=b;
        }
        return new Mesh(g.xyz,g.triangles);
    }
    private static Mesh skirtMesh() {
        final int h=11,n=72;
        Geometry g = new Geometry((h+1)*(n+1), h*n*6);
        int p=0,idx=0;
        for(int i=0;i<=h;i++) {
            float t=i/(float)h;
            for (int j=0;j<=n;j++) {
                float a=(float)(2*Math.PI*j/n);
                float ripple=(float)Math.cos(a*18f)*.021f*(.4f+.6f*t);
                float r=.22f+.47f*t+ripple;
                float x=r*(float)Math.sin(a),z=r*(float)Math.cos(a);
                g.xyz[p++]=x;g.xyz[p++]=-.11f-.77f*t;g.xyz[p++]=z;
                g.xyz[p++]=(float)Math.sin(a)*.8f;g.xyz[p++]=.47f;g.xyz[p++]=(float)Math.cos(a)*.8f;
            }
        }
        for(int i=0;i<h;i++) for(int j=0;j<n;j++) {
            short a=(short)(i*(n+1)+j),b=(short)(a+n+1);
            g.triangles[idx++]=a;g.triangles[idx++]=b;g.triangles[idx++]=(short)(a+1);
            g.triangles[idx++]=(short)(a+1);g.triangles[idx++]=b;g.triangles[idx++]=(short)(b+1);
        }
        return new Mesh(g.xyz,g.triangles);
    }
    // A curved triangular surface is fitted onto the front of the volumetric head.
    // The photo texture comes only from the user's own video, not an AI-generated face.
    private void makePhotoSurface() {
        final int n=28,m=30;
        float[] arr=new float[(n+1)*(m+1)*5]; short[] inds=new short[n*m*6];
        int k=0, ii=0;
        for (int y=0;y<=m;y++) for (int x=0;x<=n;x++) {
            float u=x/(float)n, v=y/(float)m;
            float px=(u-.5f)*.675f, py=(.5f-v)*.78f-.028f;
            float ell=(px*px)/(.41f*.41f)+((py+.035f)*(py+.035f))/(.45f*.45f);
            float front=.142f+.31f*(float)Math.sqrt(Math.max(.001f,1-ell));
            arr[k++]=px;arr[k++]=py;arr[k++]=front+.019f;
            arr[k++]=u;arr[k++]=v;
        }
        for(int y=0;y<m;y++) for(int x=0;x<n;x++) {
            short a=(short)(y*(n+1)+x), b=(short)(a+n+1);
            inds[ii++]=a;inds[ii++]=b;inds[ii++]=(short)(a+1);
            inds[ii++]=(short)(a+1);inds[ii++]=b;inds[ii++]=(short)(b+1);
        }
        ByteBuffer fb=ByteBuffer.allocateDirect(arr.length*4).order(ByteOrder.nativeOrder());
        photoVerts=fb.asFloatBuffer();photoVerts.put(arr);photoVerts.position(0);
        ByteBuffer ib=ByteBuffer.allocateDirect(inds.length*2).order(ByteOrder.nativeOrder());
        photoIndices=ib.asShortBuffer();photoIndices.put(inds);photoIndices.position(0);photoCount=ii;
    }
    private void drawPhotoFace() {
        if(!filmFace || photoTex==0)return;
        // Blend real film face with the 3D skull. Alpha zero pixels do not occlude the mesh.
        GLES20.glUseProgram(photoProgram);
        Matrix.multiplyMM(combined,0,vp,0,matrix,0);
        GLES20.glUniformMatrix4fv(uPhotoMvp,1,false,combined,0);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,photoTex);
        GLES20.glUniform1i(uPhotoTex,0);
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA,GLES20.GL_ONE_MINUS_SRC_ALPHA);
        photoVerts.position(0);
        GLES20.glVertexAttribPointer(pPosition,3,GLES20.GL_FLOAT,false,20,photoVerts);
        GLES20.glEnableVertexAttribArray(pPosition);
        photoVerts.position(3);
        GLES20.glVertexAttribPointer(pUv,2,GLES20.GL_FLOAT,false,20,photoVerts);
        GLES20.glEnableVertexAttribArray(pUv);
        photoIndices.position(0);
        GLES20.glDrawElements(GLES20.GL_TRIANGLES,photoCount,GLES20.GL_UNSIGNED_SHORT,photoIndices);
        GLES20.glDisableVertexAttribArray(pPosition); GLES20.glDisableVertexAttribArray(pUv);
        GLES20.glDisable(GLES20.GL_BLEND);
        GLES20.glUseProgram(program);
    }
    private static int shader(int type,String src) {
        int s=GLES20.glCreateShader(type);
        GLES20.glShaderSource(s,src);
        GLES20.glCompileShader(s);
        int[] ok=new int[1];GLES20.glGetShaderiv(s,GLES20.GL_COMPILE_STATUS,ok,0);
        if(ok[0]==0) throw new IllegalStateException("OpenGL shader: "+GLES20.glGetShaderInfoLog(s));
        return s;
    }
    @Override public void onSurfaceCreated(GL10 gl,EGLConfig config) {
        int vs=shader(GLES20.GL_VERTEX_SHADER,
                "attribute vec3 p; attribute vec3 n; uniform mat4 mvp; uniform mat4 model; varying float light;"+
                "void main(){ vec3 nn=normalize(mat3(model)*n); light=.59 + .41*max(0.0,dot(nn,normalize(vec3(-.45,.65,1.2)))); gl_Position=mvp*vec4(p,1.0); }");
        int fs=shader(GLES20.GL_FRAGMENT_SHADER,
                "precision mediump float; uniform vec3 color; varying float light;"+
                "void main(){ gl_FragColor=vec4(color*light,1.0); }");
        program=GLES20.glCreateProgram();
        GLES20.glAttachShader(program,vs); GLES20.glAttachShader(program,fs);
        GLES20.glLinkProgram(program);
        int[] ok=new int[1];GLES20.glGetProgramiv(program,GLES20.GL_LINK_STATUS,ok,0);
        if(ok[0]==0) throw new IllegalStateException("OpenGL program: "+GLES20.glGetProgramInfoLog(program));
        GLES20.glDeleteShader(vs);GLES20.glDeleteShader(fs);
        aPosition=GLES20.glGetAttribLocation(program,"p");
        aNormal=GLES20.glGetAttribLocation(program,"n");
        uMvp=GLES20.glGetUniformLocation(program,"mvp");
        uModel=GLES20.glGetUniformLocation(program,"model");
        uColor=GLES20.glGetUniformLocation(program,"color");
        sphere=roundMesh(15,20);cylinder=cylinderMesh(14);skirt=skirtMesh();
        int tv=shader(GLES20.GL_VERTEX_SHADER,
            "attribute vec3 p; attribute vec2 uv; uniform mat4 mvp; varying vec2 vUv;"+
            "void main(){gl_Position=mvp*vec4(p,1.0);vUv=uv;}");
        int tf=shader(GLES20.GL_FRAGMENT_SHADER,
            "precision mediump float; uniform sampler2D tex; varying vec2 vUv;"+
            "void main(){vec4 col=texture2D(tex,vUv); if(col.a<.025)discard;"+
            "gl_FragColor=vec4(min(vec3(1.0),col.rgb*1.04),col.a);}");
        photoProgram=GLES20.glCreateProgram();
        GLES20.glAttachShader(photoProgram,tv);GLES20.glAttachShader(photoProgram,tf);
        GLES20.glLinkProgram(photoProgram);
        int[] linked=new int[1]; GLES20.glGetProgramiv(photoProgram,GLES20.GL_LINK_STATUS,linked,0);
        if(linked[0]==0)throw new IllegalStateException("Foto-shader: "+GLES20.glGetProgramInfoLog(photoProgram));
        GLES20.glDeleteShader(tv);GLES20.glDeleteShader(tf);
        pPosition=GLES20.glGetAttribLocation(photoProgram,"p");
        pUv=GLES20.glGetAttribLocation(photoProgram,"uv");
        uPhotoMvp=GLES20.glGetUniformLocation(photoProgram,"mvp");
        uPhotoTex=GLES20.glGetUniformLocation(photoProgram,"tex");
        makePhotoSurface();
        Bitmap bmp=BitmapFactory.decodeResource(context.getResources(),R.drawable.marilyn_film_face);
        int[] textureIds=new int[1];GLES20.glGenTextures(1,textureIds,0);
        photoTex=textureIds[0];GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,photoTex);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_WRAP_S,GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_WRAP_T,GLES20.GL_CLAMP_TO_EDGE);
        if(bmp!=null){GLUtils.texImage2D(GLES20.GL_TEXTURE_2D,0,bmp,0);bmp.recycle();}

        GLES20.glClearColor(0f,0f,0f,0f); // essential: NO box behind the character
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glDisable(GLES20.GL_CULL_FACE);
        timeStart=SystemClock.uptimeMillis();
    }
    @Override public void onSurfaceChanged(GL10 gl,int w,int h) {
        GLES20.glViewport(0,0,w,h);
        float ratio=(float)w/Math.max(1,h);
        Matrix.orthoM(proj,0,-1.77f*ratio,1.77f*ratio,-1.77f,1.77f,1,16);
        Matrix.setLookAtM(view,0,0,0,6,0,0,0,0,1,0);
        Matrix.multiplyMM(vp,0,proj,0,view,0);
    }
    private void begin() {Matrix.setIdentityM(matrix,0);stack.clear();}
    private void push(){stack.push(matrix.clone());}
    private void pop(){float[] prev=stack.pop();System.arraycopy(prev,0,matrix,0,16);}
    private void shift(float x,float y,float z){Matrix.translateM(matrix,0,x,y,z);}
    private void turn(float angle,float x,float y,float z){Matrix.rotateM(matrix,0,angle,x,y,z);}
    private void stretch(float x,float y,float z){Matrix.scaleM(matrix,0,x,y,z);}
    private void shape(Mesh mesh, float[] color) {
        Matrix.multiplyMM(combined,0,vp,0,matrix,0);
        GLES20.glUniformMatrix4fv(uMvp,1,false,combined,0);
        GLES20.glUniformMatrix4fv(uModel,1,false,matrix,0);
        GLES20.glUniform3fv(uColor,1,color,0);
        mesh.vertex.position(0);
        GLES20.glVertexAttribPointer(aPosition,3,GLES20.GL_FLOAT,false,24,mesh.vertex);
        GLES20.glEnableVertexAttribArray(aPosition);
        mesh.vertex.position(3);
        GLES20.glVertexAttribPointer(aNormal,3,GLES20.GL_FLOAT,false,24,mesh.vertex);
        GLES20.glEnableVertexAttribArray(aNormal);
        mesh.index.position(0);
        GLES20.glDrawElements(GLES20.GL_TRIANGLES,mesh.count,GLES20.GL_UNSIGNED_SHORT,mesh.index);
    }
    private void oval(float x,float y,float z,float sx,float sy,float sz,float[] color){
        push();shift(x,y,z);stretch(sx,sy,sz);shape(sphere,color);pop();
    }
    private void limb(float x1,float y1,float z1,float x2,float y2,float z2,float r,float[] color){
        float dx=x2-x1,dy=y2-y1,dz=z2-z1;
        float len=(float)Math.sqrt(dx*dx+dy*dy+dz*dz);
        push();shift((x1+x2)/2,(y1+y2)/2,(z1+z2)/2);
        float rotation=(float)Math.toDegrees(Math.acos(Math.max(-1f,Math.min(1f,dy/Math.max(.0001f,len)))));
        if(rotation>.01f) {
            float ax=dz, az=-dx,alen=(float)Math.sqrt(ax*ax+az*az);
            if(alen>.0001f)turn(rotation,ax/alen,0,az/alen);
            else turn(rotation,1,0,0);
        }
        stretch(r,len*.5f,r);shape(cylinder,color);pop();
        oval(x1,y1,z1,r,r,r,color);
        oval(x2,y2,z2,r,r,r,color);
    }
    @Override public void onDrawFrame(GL10 gl){
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
        GLES20.glUseProgram(program);
        float t=(SystemClock.uptimeMillis()-timeStart)/1000f;
        float breathe=(float)Math.sin(t*2)*.013f;
        float side=(float)Math.sin(t*1.25f)*2f;
        int p=pose;
        boolean wave=(p==3 || SystemClock.uptimeMillis()<waveUntil);
        float run = (p==1 || p==2) ? (float)Math.sin(t*6)*.14f : 0f;
        float jump = p==4 ? .16f+(float)Math.abs(Math.sin(t*4.8f))*.20f : 0f;
        begin();shift(0,jump,0);turn(yaw,0,1,0);turn(side,0,0,1);
        if(p==5)turn(-7,0,0,1);
        // legs and tiny shoes
        limb(-.16f,-.67f,0,-.15f,-1.35f+run,0,.082f,SKIN);
        limb(.16f,-.67f,0,.15f,-1.35f-run,0,.082f,SKIN);
        oval(-.16f,-1.36f+run,.115f,.115f,.072f,.205f,SOLE);
        oval(.16f,-1.36f-run,.115f,.115f,.072f,.205f,SOLE);
        // bodice + neck, waist and genuine flared 3D pleated skirt
        oval(0,.16f+breathe,0,.30f,.35f,.195f,DRESS);
        oval(0,-.10f,0,.20f,.12f,.17f,DRESS);
        shape(skirt,WHITE);
        // pleat details, their locations are 3D (not drawn on a bitmap)
        for(int k=0;k<18;k++) {
            float a=(float)(k*2*Math.PI/18);
            float c=(float)Math.cos(a),s=(float)Math.sin(a);
            limb(.24f*s,-.17f,.24f*c,.60f*s,-.83f,.60f*c,.009f,PLEAT);
        }
        // halter straps and V neckline on chest
        limb(-.20f,.34f,.16f,-.055f,.56f,.105f,.055f,DRESS);
        limb(.20f,.34f,.16f,.055f,.56f,.105f,.055f,DRESS);
        oval(-.145f,.33f,.16f,.155f,.15f,.11f,WHITE);
        oval(.145f,.33f,.16f,.155f,.15f,.11f,WHITE);
        oval(0,.50f,0,.09f,.13f,.09f,SKIN);
        // arms and hands; each arm has 3D upper/lower segments
        drawArm(-1,t,wave,p,run);
        drawArm(1,t,false,p,-run);
        // oversized cartoon head, rotated separately
        push();shift(0,1.02f+breathe,0);stretch(.81f,.83f,.84f);
        turn((p==7?-11f:0f)+(float)Math.sin(t*.9f)*2.2f,0,0,1);
        if(p==5)turn(10,1,0,0);
        // hair back and side bob -- visible from behind and through 360 degrees
        oval(0,.03f,-.15f,.54f,.49f,.45f,HAIR_DARK);
        oval(0,.085f,-.16f,.51f,.52f,.43f,HAIR);
        // face volume and chin
        oval(0,-.035f,.142f,.41f,.45f,.31f,SKIN);
        oval(0,-.305f,.28f,.24f,.14f,.16f,SKIN);
        if(filmFace) drawPhotoFace();
        if(!filmFace) {
        // rosy cheeks
        oval(-.265f,-.165f,.384f,.091f,.070f,.024f,BLUSH);
        oval(.265f,-.165f,.384f,.091f,.070f,.024f,BLUSH);
        float blink=(float)(Math.sin(t*1.62f)> .993f ? .13f:1f);
        for(int sign:new int[]{-1,1}) {
            float ex=sign*.171f;
            oval(ex,.05f,.421f,.134f,.105f*blink,.047f,EYE_WHITE);
            oval(ex+sign*.023f,.044f,.463f,.064f,.081f*blink,.030f,BLUE);
            oval(ex+sign*.023f,.043f,.491f,.031f,.059f*blink,.017f,PUPIL);
            oval(ex+sign*.014f,.076f,.509f,.017f,.020f,.012f,WHITE);
            // arched eyebrows and eyelashes
            limb(ex-.073f,.197f,.413f,ex+.070f,.205f,.423f,.020f,LASH);
            limb(ex+sign*.094f,.100f,.449f,ex+sign*.146f,.139f,.436f,.016f,LASH);
        }
        oval(0,-.088f,.459f,.062f,.10f,.09f,SKIN_SHADE); // protruding nose
        // Simple speech indicator: open/close mouth while TTS is talking.
        // This is rhythmic animation, NOT phoneme-accurate lip synchronization.
        float mouthOpen=speaking ? .022f + .052f*(.5f+.5f*(float)Math.sin(t*19.0f)) : 0f;
        if(speaking) oval(0,-.255f,.470f,.087f,mouthOpen,.016f,LASH);
        oval(-.058f,-.234f+.30f*mouthOpen,.474f,.069f,.026f,.023f,LIP);
        oval(.058f,-.234f+.30f*mouthOpen,.474f,.069f,.026f,.023f,LIP);
        oval(0,-.268f-mouthOpen,.468f,.095f,.023f,.023f,LIP);
        }
        // Blonde bob: multiple overlapping 3D curls, based on the film silhouette.
        for(int k=0;k<36;k++) {
            float a=(float)(2*Math.PI*k/36);
            float yy=(float)Math.sin(a);
            float xx=(float)Math.cos(a);
            float x=xx*.51f,y=.18f+yy*.31f;
            float z=k<18 ? -.05f : -.22f;
            oval(x,y,z,.105f,.13f,.115f,(k%4==0)?HAIR_LIGHT:(k%7==0?HAIR_DARK:HAIR));
        }
        for(int k=0;k<13;k++) {
            float a=(float)(Math.PI*k/12);
            float x=(float)Math.cos(a)*.49f,y=.36f+(float)Math.sin(a)*.165f;
            oval(x,y,.025f,.15f,.145f,.155f,k%3==0?HAIR_DARK:HAIR_LIGHT);
        }
        // recognisable front swoop/curl on her forehead
        oval(-.19f,.36f,.305f,.23f,.135f,.145f,HAIR_LIGHT);
        oval(-.015f,.35f,.355f,.16f,.09f,.115f,HAIR);
        // bob curls close to her ears
        oval(-.47f,-.08f,.19f,.14f,.16f,.18f,HAIR_LIGHT);
        oval(.47f,-.08f,.19f,.14f,.16f,.18f,HAIR);
        pop(); // head
    }
    private void drawArm(int sign,float t,boolean waving,int pose,float movement){
        float a=sign*.32f, z=.015f;
        float elbowX=sign*.42f, elbowY=.17f;
        float handX=sign*.13f,handY=-.12f,handZ=.35f;
        if(waving) {
            elbowX=sign*.57f;elbowY=.45f;handX=sign*(.67f+(float)Math.sin(t*10)*.035f);
            handY=.87f+(float)Math.sin(t*10)*.07f;handZ=.22f;
        } else if(pose==4) {
            elbowX=sign*.52f;elbowY=.42f;handX=sign*.76f;handY=.74f;handZ=.07f;
        } else if(pose==7 && sign==1) {
            elbowX=sign*.36f;elbowY=.28f;handX=sign*.18f;handY=.81f;handZ=.43f;
        } else if(pose==1 || pose==2) {
            elbowX=sign*.42f;elbowY=.17f;handX=sign*.35f;handY=-.05f+movement;handZ=.08f;
        } else if(pose==5) {
            handX=sign*.51f;handY=-.14f;handZ=.1f;
        }
        limb(a,.38f,z,elbowX,elbowY,.10f,.072f,SKIN);
        limb(elbowX,elbowY,.10f,handX,handY,handZ,.066f,SKIN);
        oval(handX,handY,handZ,.078f,.10f,.06f,SKIN);
    }
}
