package nl.marilyn.origineel;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import java.util.Calendar;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

/** Transparent movable Android overlay. One finger moves; two fingers spin 3D. */
public class OverlayService extends Service {
    static final String ACTION_START="nl.marilyn.origineel.START";
    static final String ACTION_SPEECH="nl.marilyn.origineel.SPEECH";
    static final String ACTION_REFRESH="nl.marilyn.origineel.REFRESH";
    static final String ACTION_VOICE_RESULT="nl.marilyn.origineel.VOICE_RESULT";
    private static final String ACTION_STOP="nl.marilyn.origineel.STOP";
    private static final String CHANNEL="marilyn_overlay_channel";
    private static final int NOTIFICATION_ID=1109;
    static volatile boolean active=false;
    private WindowManager manager;
    private WindowManager.LayoutParams params;
    private View floating;
    private ImageView flat;
    private Marilyn3DView threeD;
    private int pose=0, size=100;
    private boolean modelMode;
    private TextToSpeech tts;
    private boolean receiverRegistered = false;
    private final BroadcastReceiver unlockReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if(Intent.ACTION_USER_PRESENT.equals(intent.getAction())) {
                handler.postDelayed(() -> maybeGreet(), 2200);
            }
        }
    };
    private void maybeGreet() {
        if(!active || floating == null) return;
        android.content.SharedPreferences pref=getSharedPreferences("marilyn_options",MODE_PRIVATE);
        if(!pref.getBoolean("greet_unlock",false)) return;
        int hour=Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if(hour < 9 || hour >= 22) return;
        long now=System.currentTimeMillis();
        long last=pref.getLong("last_greet_at",0L);
        if(now-last < 3L*60*60*1000) return;
        int n=pref.getInt("greeting_counter",0);
        pref.edit().putLong("last_greet_at",now).putInt("greeting_counter",n+1).apply();
        String[] english={
            "Hello, darling! How is your day going? Anything interesting on your mind?",
            "Hi there! It's lovely to see you. What have you been working on lately?",
            "Hello! Is there something you would like a fresh perspective on today?",
            "There you are! Anything you're looking forward to today?"
        };
        String[] dutch={
            "Hoi, wat leuk dat je er weer bent! Hoe gaat het met je?",
            "Hallo! Waar ben je de laatste tijd mee bezig? Vertel eens!",
            "Hoi! Kan ik ergens met je over meedenken vandaag?",
            "Daar ben je weer! Is er iets waar je vandaag naar uitkijkt?"
        };
        String msg=(VoiceStyle.english(this)?english:dutch)[Math.floorMod(n,4)];
        speakReply(msg);
        if(threeD!=null) threeD.wave();
    }
    private boolean voiceReady=false;
    private String pendingReply;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable moveAuto=new Runnable() {
        @Override public void run() {
            if (floating==null || !getSharedPreferences("marilyn_options",MODE_PRIVATE).getBoolean("auto",false)) return;
            pose=(pose+1)%MarilynData.IMAGES.length;
            setPoseOnView();
            handler.postDelayed(this,4300);
        }
    };
    @Override public void onCreate(){
        super.onCreate();
        manager=(WindowManager)getSystemService(WINDOW_SERVICE);
        IntentFilter filter=new IntentFilter(Intent.ACTION_USER_PRESENT);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(unlockReceiver,filter,Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(unlockReceiver,filter);
        receiverRegistered=true;
        tts=new TextToSpeech(this, result->{
            voiceReady=(result==TextToSpeech.SUCCESS);
            if(voiceReady && tts!=null) VoiceStyle.apply(this,tts);
            if(voiceReady && pendingReply!=null) handler.post(()->{
                String toSay=pendingReply;
                pendingReply=null;
                speakReply(toSay);
            });
            if(voiceReady && tts!=null) tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
                @Override public void onStart(String id){ handler.post(()->setSpeaking(true)); }
                @Override public void onDone(String id){ handler.post(()->setSpeaking(false)); }
                @Override public void onError(String id){ handler.post(()->setSpeaking(false)); }
            });
        });
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if(intent!=null && ACTION_STOP.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
        if(intent!=null && ACTION_SPEECH.equals(intent.getAction())){
            setSpeaking(intent.getBooleanExtra("is_speaking",false));
            return START_STICKY;
        }
        if(Build.VERSION.SDK_INT>=23 && !Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY;}
        createNotification();
        startForeground(NOTIFICATION_ID,notification());
        boolean desired=getSharedPreferences("marilyn_options",MODE_PRIVATE).getBoolean("three_d",true);
        if(floating==null || modelMode!=desired) {
            removeFloating();
            try {createFloating(desired);active=true;}
            catch (RuntimeException e){active=false;stopSelf();return START_NOT_STICKY;}
        }
        refresh();
        if(intent!=null && ACTION_VOICE_RESULT.equals(intent.getAction())) {
            String answer=intent.getStringExtra("reply");
            if(answer!=null && !answer.isEmpty()) speakReply(answer);
        }
        return START_STICKY;
    }
    private void createNotification(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Marilyn zwevend",NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Marilyn los op het scherm, ook boven andere apps.");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }
    private Notification notification(){
        int flags=PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE;
        PendingIntent open=PendingIntent.getActivity(this,1,new Intent(this,MainActivity.class),flags);
        Intent stop=new Intent(this,OverlayService.class);stop.setAction(ACTION_STOP);
        PendingIntent close=PendingIntent.getService(this,2,stop,flags);
        Intent talk = new Intent(this,ConversationActivity.class);
        talk.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        talk.putExtra("listen_now", true);
        PendingIntent mic = PendingIntent.getActivity(this,3,talk,flags);
        return new Notification.Builder(this,CHANNEL)
            .setContentTitle("Marilyn zweeft op je scherm")
            .setContentText("Vasthouden: praten. 1 vinger: slepen. 2: draaien.")
            .setSmallIcon(android.R.drawable.star_on)
            .setOngoing(true).setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_edit,"🎙 Praten",mic)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel,"Stoppen",close).build();
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private void createFloating(boolean as3D) {
        modelMode=as3D;
        if(as3D){
            threeD=new Marilyn3DView(this);
            threeD.setPose(pose);
            threeD.setFilmFace(getSharedPreferences("marilyn_options",MODE_PRIVATE).getBoolean("film_face",true));
            threeD.setAngle(getSharedPreferences("marilyn_options",MODE_PRIVATE).getFloat("yaw",0f));
            floating=threeD;
        } else {
            flat=new ImageView(this);
            flat.setImageResource(MarilynData.IMAGES[pose]);
            flat.setScaleType(ImageView.ScaleType.FIT_CENTER);
            flat.setBackgroundColor(Color.TRANSPARENT);
            floating=flat;
        }
        params=new WindowManager.LayoutParams(dp(146),dp(285),
             Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,
             WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
             WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
             WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
             PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START;
        int sw=getResources().getDisplayMetrics().widthPixels;
        params.x=getSharedPreferences("marilyn_options",MODE_PRIVATE).getInt("overlay_x",Math.max(0,sw-dp(162)));
        params.y=getSharedPreferences("marilyn_options",MODE_PRIVATE).getInt("overlay_y",dp(180));
        floating.setOnTouchListener(new View.OnTouchListener(){
            private float firstX,firstY,rotateX,initialYaw;
            private int firstWindowX,firstWindowY;
            private boolean moving,multitouch,longPressed;
            private final Runnable longHold=()->{
                if(!moving && !multitouch && floating!=null){
                    longPressed=true;
                    try {
                        Intent listen=new Intent(OverlayService.this,ConversationActivity.class);
                        listen.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        listen.putExtra("listen_now", true);
                        startActivity(listen);
                    } catch(Exception ex) {
                        android.widget.Toast.makeText(OverlayService.this,
                            "Gebruik de knop 'Praten' in de Marilyn-melding.",
                            android.widget.Toast.LENGTH_LONG).show();
                    }
                }
            };
            @Override public boolean onTouch(View v,MotionEvent e){
                int action=e.getActionMasked();
                switch(action){
                    case MotionEvent.ACTION_DOWN:
                        firstX=e.getRawX();firstY=e.getRawY();
                        firstWindowX=params.x;firstWindowY=params.y;
                        moving=false;multitouch=false;longPressed=false;
                        handler.removeCallbacks(longHold);
                        handler.postDelayed(longHold,850);
                        return true;
                    case MotionEvent.ACTION_POINTER_DOWN:
                        handler.removeCallbacks(longHold);
                        if(threeD!=null && e.getPointerCount()>=2){
                            multitouch=true;
                            rotateX=e.getX(0)+e.getX(1);
                            initialYaw=threeD.getAngle();
                            return true;
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if(longPressed)return true;
                        if(multitouch && threeD!=null && e.getPointerCount()>=2){
                            float shift=e.getX(0)+e.getX(1)-rotateX;
                            float angle=initialYaw+shift*.85f;
                            threeD.setAngle(angle);
                            getSharedPreferences("marilyn_options",MODE_PRIVATE).edit().putFloat("yaw",angle).apply();
                            return true;
                        }
                        if(multitouch)return true;
                        int dx=Math.round(e.getRawX()-firstX),dy=Math.round(e.getRawY()-firstY);
                        if(Math.abs(dx)>dp(5)||Math.abs(dy)>dp(5)){
                            moving=true;
                            handler.removeCallbacks(longHold);
                        }
                        if(moving) {
                            int w=getResources().getDisplayMetrics().widthPixels;
                            int h=getResources().getDisplayMetrics().heightPixels;
                            params.x=Math.max(0,Math.min(w-params.width,firstWindowX+dx));
                            params.y=Math.max(0,Math.min(h-params.height,firstWindowY+dy));
                            try{manager.updateViewLayout(floating,params);}catch(IllegalArgumentException ignored){}
                        }
                        return true;
                    case MotionEvent.ACTION_POINTER_UP:return true;
                    case MotionEvent.ACTION_UP:
                        handler.removeCallbacks(longHold);
                        if(!longPressed && !moving && !multitouch){
                            wave();
                            if(VoiceStyle.speakOnTap(OverlayService.this))speakTap();
                        }
                        if(moving)getSharedPreferences("marilyn_options",MODE_PRIVATE).edit()
                            .putInt("overlay_x",params.x).putInt("overlay_y",params.y).apply();
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        handler.removeCallbacks(longHold);
                        return true;
                }
                return true;
            }
        });
        manager.addView(floating,params);
    }
    private void setPoseOnView() {
        if(flat!=null)flat.setImageResource(MarilynData.IMAGES[pose]);
        if(threeD!=null)threeD.setPose(pose);
    }
    private void setSpeaking(boolean talking){if(threeD!=null)threeD.setSpeaking(talking);}
    private void speakTap(){
        if(!voiceReady || tts==null)return;
        VoiceStyle.apply(this,tts);
        SpokenCommand.rememberPhrase(this,pose);
        tts.speak(VoiceStyle.line(this,pose),TextToSpeech.QUEUE_FLUSH,null,"marilyn_overlay");
    }
    private void speakReply(String reply){
        if (reply==null || reply.isEmpty())return;
        if (!voiceReady || tts==null) {
            pendingReply=reply;
            return;
        }
        VoiceStyle.apply(this,tts);
        tts.speak(reply,TextToSpeech.QUEUE_FLUSH,null,"marilyn_voice_response");
    }
    private void wave(){
        if(threeD!=null){threeD.wave();return;}
        if(flat==null)return;
        final int was=pose;
        flat.setImageResource(MarilynData.IMAGES[3]);
        flat.animate().cancel();
        flat.animate().rotation(6).setDuration(180).withEndAction(()->
            flat.animate().rotation(-6).setDuration(180).withEndAction(()->
                flat.animate().rotation(0).setDuration(180).withEndAction(()->{
                    if(flat!=null)flat.setImageResource(MarilynData.IMAGES[was]);
                }).start()).start()).start();
    }
    private void refresh(){
        if(floating==null)return;
        pose=MarilynData.validPose(getSharedPreferences("marilyn_options",MODE_PRIVATE).getInt("pose",0));
        size=MarilynData.validSize(getSharedPreferences("marilyn_options",MODE_PRIVATE).getInt("size",100));
        setPoseOnView();
        if(threeD!=null){
            threeD.setAngle(getSharedPreferences("marilyn_options",MODE_PRIVATE).getFloat("yaw",0f));
            threeD.setFilmFace(getSharedPreferences("marilyn_options",MODE_PRIVATE).getBoolean("film_face",true));
        }
        int width=dp(146f*size/100f),height=dp(285f*size/100f);
        int maxW=Math.max(dp(70),getResources().getDisplayMetrics().widthPixels-dp(12));
        int maxH=Math.max(dp(80),getResources().getDisplayMetrics().heightPixels-dp(60));
        float f=Math.min(1,Math.min(maxW/(float)width,maxH/(float)height));
        params.width=Math.round(width*f);params.height=Math.round(height*f);
        params.x=Math.max(0,Math.min(params.x,Math.max(0,getResources().getDisplayMetrics().widthPixels-params.width)));
        params.y=Math.max(0,Math.min(params.y,Math.max(0,getResources().getDisplayMetrics().heightPixels-params.height)));
        try{manager.updateViewLayout(floating,params);}catch(IllegalArgumentException ignored){}
        handler.removeCallbacks(moveAuto);
        if(getSharedPreferences("marilyn_options",MODE_PRIVATE).getBoolean("auto",false))handler.postDelayed(moveAuto,4300);
    }
    private void removeFloating(){
        handler.removeCallbacks(moveAuto);
        if(floating!=null){try{manager.removeView(floating);}catch(Exception ignored){}floating=null;}
        flat=null;threeD=null;
    }
    @Override public void onDestroy(){
        if(receiverRegistered){try{unregisterReceiver(unlockReceiver);}catch(Exception ignored){} receiverRegistered=false;}
        removeFloating();active=false;
        if(tts!=null){tts.stop();tts.shutdown();tts=null;}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent){return null;}
}
