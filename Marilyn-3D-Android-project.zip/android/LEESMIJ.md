# Marilyn 3D – Android, versie 0.2

Een origineel gestileerd **Marilyn-achtig 3D-cartoonfiguurtje** voor Android.
Geen afhankelijkheid van Three.js of online 3D-bibliotheken. De 3D-animatie werkt offline.

## Functies
- **3D WebGL**-figuur met haar, gezicht, jurk en bewegende armen, animaties en knipperen.
- **Canvas-standby** als WebGL op een toestel is geblokkeerd.
- Sleep over het figuur: draaien. Tik: zwaaien. Knoppen: zwaaien, dansen, praten,
  spraakherkenning, groter, kleiner, ×2, sluiten.
- Android zwevend venster boven andere apps, versleepbaar via bovenrand.
- Android tekst-naar-spraak (Nederlandse systeemstem).
- Spraakherkenning via geïnstalleerde systeem-spraakherkenner en enkele lokale commando's.
- ChatGPT-knop opent ChatGPT los (geen geïntegreerd vrij AI-gesprek).

## APK bouwen

**Methode A — GitHub Actions (geen pc nodig maar wel GitHub-account):**
1. Maak op github.com een privé-repository aan.
2. Zet de **inhoud van deze `android`-map** in de hoofdmap van die repository,
   dus `settings.gradle.kts`, `app/`, `.github/` enzovoort.
3. Kies in GitHub het tabblad **Actions** → **Bouw Marilyn Android APK** → **Run workflow**.
4. Open na een geslaagde build de workflow-run, download het artifact `Marilyn-3D-Android-debug-APK`
   en pak de ZIP uit. Daarin vind je `app-debug.apk`.
5. Kopieer de APK naar je eigen Samsung en open deze om te installeren.
   Samsung kan toestemming vragen voor installatie uit die bron. Doe dit alleen met je eigen APK.

**Methode B — Android Studio:**
1. Open deze map als Android Studio-project; met Gradle 8.10.2 en JDK 17.
2. Sync de Gradle-dependencies en Android SDK API 35.
3. Bouw met `gradle assembleDebug` (of Build → Build APK(s) als Gradle beschikbaar is).
4. Installatiebestand: `app/build/outputs/apk/debug/app-debug.apk`.

## Gebruik
1. Open Marilyn 3D.
2. Geef toestemming voor **Weergeven over andere apps**.
3. Tik op **Start zwevende Marilyn**.
4. Tik op de 3D-knoppen. Schuif de bovenrand om de overlay te verplaatsen.
5. Voor microfoon tik 🎙️. De systeemspraakherkenner vraagt zo nodig toestemming.

## Grenzen en veiligheid
- Dit is een functionele **broncodeversie**, geen lokaal gebouwde/geteste APK.
  In deze omgeving ontbreken Android SDK/Gradle en de Samsung om installatie op te controleren.
- Voice Activity moet door Android toegestaan worden terwijl de overlay zichtbaar is.
  Systeemversie, microfoon-app en fabrikantinstellingen kunnen dat beperken.
- Niet elke app staat zwevende vensters toe, bijvoorbeeld sommige bank-/beveiligingsapps.
- De gebruiker krijgt niet automatisch toegang tot zijn ChatGPT-account via de 3D-figuur.
  Voor echte gesprek-API-integratie is een aparte beveiligde API-backend nodig.
- Geen continue microfoonopname; luisteren start uitsluitend na aantikken.
- Zonder internet werken 3D, animaties en Android TTS, afhankelijk van de aanwezige taalgegevens.
  Spraakherkenning kan bij de externe spraakdienst internet nodig hebben.
- Dit project is geen officiële OpenAI Work-pet.
