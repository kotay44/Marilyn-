package nl.marilyn.assistant

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(x: Int) = (resources.displayMetrics.density * x).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val wrap = ScrollView(this).apply { setBackgroundColor(Color.rgb(255, 241, 246)) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(38), dp(24), dp(28))
        }
        wrap.addView(box)
        fun text(t: String, size: Float) {
            box.addView(TextView(this).apply {
                text=t; textSize=size; setTextColor(Color.rgb(112, 50, 80))
                gravity=Gravity.CENTER; setPadding(0, dp(10), 0, dp(16))
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        fun button(t: String, click: () -> Unit) {
            box.addView(Button(this).apply {
                text=t; textSize=16f; setAllCaps(false)
                setOnClickListener { click() }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin=dp(10) })
        }
        text("💕 Marilyn 3D", 29f)
        text("Een echt interactief 3D-cartoonfiguurtje dat boven je apps kan zweven. Het 3D-model werkt ook offline.", 17f)
        button("1. Geef toestemming: over andere apps") { overlaySettings() }
        button("2. Start zwevende Marilyn") { launchMarilyn() }
        button("Stop Marilyn") { stopService(Intent(this, OverlayService::class.java)) }
        button("Open ChatGPT voor vrije AI-gesprekken") {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com/")))
        }
        text("Bediening: zwaai 👋, dans 💃, spraak 🔊, microfoon 🎙, ChatGPT 💬, groter + en ×2. Sleep aan de bovenrand om Marilyn te verplaatsen. Draai haar met je vinger.", 14f)
        text("Let op: dit 3D-figuurtje bevat geen ingebouwde ChatGPT-API. De 💬-knop opent ChatGPT apart. Spraakherkenning gebruikt de spraakdiensten op je telefoon.", 13f)
        setContentView(wrap)
    }

    private fun overlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }
    private fun launchMarilyn() {
        if (!Settings.canDrawOverlays(this)) { overlaySettings(); return }
        val i=Intent(this, OverlayService::class.java)
        startForegroundService(i)
        moveTaskToBack(true)
    }
}
