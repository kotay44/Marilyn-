package nl.marilyn.assistant

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.*
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import org.json.JSONObject
import java.util.Locale
import kotlin.math.roundToInt

class OverlayService : Service() {
    companion object {
        const val ACTION_VOICE="nl.marilyn.assistant.VOICE_RESULT"
        const val EXTRA_SPEECH="recognized_text"
        private const val CHANNEL="marilyn_3d_overlay"
    }
    private var manager:WindowManager?=null
    private var floating:WebView?=null
    private var params:WindowManager.LayoutParams?=null
    private var tts:TextToSpeech?=null
    private val handler=Handler(Looper.getMainLooper())
    override fun onBind(intent:Intent?):IBinder?=null
    private fun dp(x:Int)=(x*resources.displayMetrics.density).roundToInt()

    override fun onCreate() {
        super.onCreate()
        val nm=getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL,"Marilyn 3D actief",NotificationManager.IMPORTANCE_LOW))
        val open=PendingIntent.getActivity(this,0,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notification=Notification.Builder(this,CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_myplaces)
            .setContentTitle("Marilyn 3D beweegt op je scherm")
            .setContentText("Tik om Marilyn te beheren")
            .setOngoing(true)
            .setContentIntent(open)
            .build()
        startForeground(12,notification)
        tts=TextToSpeech(this) { code -> if(code==TextToSpeech.SUCCESS) tts?.language=Locale.forLanguageTag("nl-NL") }
        createFloatingView()
    }

    override fun onStartCommand(intent:Intent?, flags:Int, startId:Int):Int {
        if(intent?.action==ACTION_VOICE){
            val heard=intent.getStringExtra(EXTRA_SPEECH).orEmpty()
            if(heard.isBlank()) js("Marilyn.speak('Ik kon je niet verstaan of de spraakherkenner ontbreekt.')")
            else js("Marilyn.heard(${JSONObject.quote(heard)})")
        }
        return START_STICKY
    }

    private fun createFloatingView(){
        if(!Settings.canDrawOverlays(this)){stopSelf();return}
        manager=getSystemService(WINDOW_SERVICE) as WindowManager
        val w=WebView(this)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.settings.apply {
            javaScriptEnabled=true
            domStorageEnabled=false
            allowFileAccess=true
            allowContentAccess=false
            allowFileAccessFromFileURLs=false
            allowUniversalAccessFromFileURLs=false
        }
        w.webChromeClient=WebChromeClient()
        w.addJavascriptInterface(AndroidBridge(),"Android")
        w.setLayerType(View.LAYER_TYPE_HARDWARE,null)
        val dm=resources.displayMetrics
        val maxWidth=(dm.widthPixels-dp(14)).coerceAtLeast(dp(180))
        val width=dp(260).coerceAtMost(maxWidth)
        val height=(width*1.52f).roundToInt().coerceAtMost(dm.heightPixels-dp(50))
        val p=WindowManager.LayoutParams(width,height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.START; x=dp(18);y=dp(90) }
        // Only the upper 34dp acts as a drag handle. All other gestures go to the 3D viewer.
        var moving=false; var pointerX=0f; var pointerY=0f; var fromX=0; var fromY=0
        w.setOnTouchListener { _,e ->
            when(e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    moving=e.y < dp(34)
                    if(moving){pointerX=e.rawX;pointerY=e.rawY;fromX=p.x;fromY=p.y}
                    moving
                }
                MotionEvent.ACTION_MOVE -> {
                    if(moving){
                        p.x=(fromX+(e.rawX-pointerX).roundToInt()).coerceIn(0,(dm.widthPixels-p.width).coerceAtLeast(0))
                        p.y=(fromY+(e.rawY-pointerY).roundToInt()).coerceIn(0,(dm.heightPixels-p.height).coerceAtLeast(0))
                        manager?.updateViewLayout(w,p)
                    };moving
                }
                MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL -> {
                    val wasMoving=moving; moving=false;wasMoving
                }
                else -> moving
            }
        }
        try {
            floating=w;params=p;manager?.addView(w,p)
            w.loadUrl("file:///android_asset/marilyn.html?overlay=1")
        } catch(e:Exception){w.destroy();floating=null;stopSelf()}
    }

    private fun js(code:String) {handler.post { floating?.evaluateJavascript(code,null) } }
    private fun updateSize(large:Boolean=false,shift:Int=0){
        val p=params?:return
        val dm=resources.displayMetrics
        val maxW=(dm.widthPixels-dp(14)).coerceAtLeast(dp(180))
        val next=if(large)maxW else if(shift==0)dp(260) else p.width+dp(shift)
        p.width=next.coerceIn(dp(165).coerceAtMost(maxW),maxW)
        p.height=(p.width*1.52f).roundToInt().coerceAtMost(dm.heightPixels-dp(45))
        p.x=p.x.coerceIn(0,(dm.widthPixels-p.width).coerceAtLeast(0))
        p.y=p.y.coerceIn(0,(dm.heightPixels-p.height).coerceAtLeast(0))
        floating?.let{manager?.updateViewLayout(it,p)}
    }
    inner class AndroidBridge {
        @JavascriptInterface fun resize(difference:Int){handler.post{updateSize(shift=difference.coerceIn(-80,80))}}
        @JavascriptInterface fun setLarge(large:Boolean){handler.post{updateSize(large=large)}}
        @JavascriptInterface fun speak(words:String){handler.post{tts?.speak(words.take(900),TextToSpeech.QUEUE_FLUSH,null,"marilyn-${System.nanoTime()}")}}
        @JavascriptInterface fun stopSpeak(){handler.post{tts?.stop()}}
        @JavascriptInterface fun listen(){handler.post{
            try {
                val i=Intent(this@OverlayService,VoiceActivity::class.java).apply {addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)}
                startActivity(i)
            }catch(e:Exception){js("Marilyn.speak('Spraakherkenning kon niet worden geopend.')")}
        }}
        @JavascriptInterface fun openChat(){handler.post{
            try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://chatgpt.com/")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}
            catch(_:Exception){js("Marilyn.speak('ChatGPT kon niet worden geopend.')")}
        }}
        @JavascriptInterface fun close(){handler.post{stopSelf()}}
    }

    override fun onDestroy(){
        floating?.let{try{manager?.removeView(it)}catch(_:Exception){};it.destroy()}
        floating=null
        tts?.stop();tts?.shutdown();tts=null
        super.onDestroy()
    }
}
