package nl.marilyn.assistant

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent

/* Starts the user's installed voice recognizer. Does not listen in the background. */
class VoiceActivity : Activity() {
    private val REQUEST_SPEECH=42
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if(savedInstanceState==null) {
            try {
                val speech=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "nl-NL")
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, "Praat met Marilyn")
                startActivityForResult(speech, REQUEST_SPEECH)
            } catch (_: ActivityNotFoundException) { sendBack(null); finish() }
        }
    }
    override fun onActivityResult(requestCode: Int,resultCode: Int,data: Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==REQUEST_SPEECH) {
            val words=if(resultCode==RESULT_OK) data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() else null
            sendBack(words)
            finish()
        }
    }
    private fun sendBack(words: String?) {
        val intent=Intent(this,OverlayService::class.java).apply {
            action=OverlayService.ACTION_VOICE
            putExtra(OverlayService.EXTRA_SPEECH, words ?: "")
        }
        startForegroundService(intent)
    }
}
